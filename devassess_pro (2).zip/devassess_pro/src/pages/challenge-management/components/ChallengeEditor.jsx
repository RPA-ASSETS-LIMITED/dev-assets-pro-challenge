import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';

const ChallengeEditor = ({ challenge, onUpdate, onDelete }) => {
  const [formData, setFormData] = useState(challenge);
  const [activeTab, setActiveTab] = useState('details');
  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  useEffect(() => {
    setFormData(challenge);
    setHasUnsavedChanges(false);
  }, [challenge]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
      updatedAt: new Date()
    }));
    setHasUnsavedChanges(true);
  };

  const handleNestedInputChange = (parentField, field, value) => {
    setFormData(prev => ({
      ...prev,
      [parentField]: {
        ...prev[parentField],
        [field]: value
      },
      updatedAt: new Date()
    }));
    setHasUnsavedChanges(true);
  };

  const handleSave = async (status = formData.status) => {
    setIsSaving(true);
    try {
      const updatedChallenge = {
        ...formData,
        status,
        updatedAt: new Date()
      };
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      onUpdate(updatedChallenge);
      setHasUnsavedChanges(false);
    } catch (error) {
      console.error('Error saving challenge:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handlePublish = () => {
    handleSave('published');
  };

  const handleDelete = async () => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
      onDelete(challenge.id);
      setShowDeleteModal(false);
    } catch (error) {
      console.error('Error deleting challenge:', error);
    }
  };

  const tabs = [
    { id: 'details', label: 'Challenge Details', icon: 'FileText' },
    { id: 'assignment', label: 'Assignment Rules', icon: 'Users' },
    { id: 'evaluation', label: 'Evaluation Criteria', icon: 'CheckSquare' },
    { id: 'template', label: 'Git Template', icon: 'GitBranch' }
  ];

  const formatDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="bg-surface rounded-lg border border-border">
      {/* Header */}
      <div className="p-6 border-b border-border-light">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <h2 className="text-xl font-semibold text-text-primary">
              {formData.title}
            </h2>
            {hasUnsavedChanges && (
              <span className="inline-flex items-center space-x-1 text-warning text-sm">
                <Icon name="AlertCircle" size={16} />
                <span>Unsaved changes</span>
              </span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleSave('draft')}
              disabled={isSaving}
              className="inline-flex items-center space-x-2 px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-secondary-50 transition-smooth min-h-touch disabled:opacity-50"
            >
              {isSaving ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Save" size={16} />}
              <span>Save Draft</span>
            </button>
            <button
              onClick={handlePublish}
              disabled={isSaving}
              className="inline-flex items-center space-x-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-smooth min-h-touch disabled:opacity-50"
            >
              <Icon name="Upload" size={16} />
              <span>Publish</span>
            </button>
            <button
              onClick={() => setShowDeleteModal(true)}
              className="inline-flex items-center space-x-2 text-error hover:bg-error-50 px-4 py-2 rounded-lg transition-smooth min-h-touch"
            >
              <Icon name="Trash2" size={16} />
              <span>Delete</span>
            </button>
          </div>
        </div>

        {/* Meta Info */}
        <div className="flex items-center space-x-6 text-sm text-text-secondary">
          <span>Created: {formatDate(formData.createdAt)}</span>
          <span>Updated: {formatDate(formData.updatedAt)}</span>
          <span>Status: <span className={`font-medium ${
            formData.status === 'published' ? 'text-success' : 'text-warning'
          }`}>{formData.status}</span></span>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-border-light">
        <nav className="flex space-x-8 px-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm transition-smooth ${
                activeTab === tab.id
                  ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary'
              }`}
            >
              <Icon name={tab.icon} size={16} />
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="p-6">
        {activeTab === 'details' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Challenge Title
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Category
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => handleInputChange('category', e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                >
                  <option value="Frontend">Frontend</option>
                  <option value="Backend">Backend</option>
                  <option value="Full Stack">Full Stack</option>
                  <option value="Mobile">Mobile</option>
                  <option value="DevOps">DevOps</option>
                  <option value="Data Science">Data Science</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Difficulty Level
                </label>
                <select
                  value={formData.difficulty}
                  onChange={(e) => handleInputChange('difficulty', e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                >
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Estimated Time
                </label>
                <input
                  type="text"
                  value={formData.estimatedTime}
                  onChange={(e) => handleInputChange('estimatedTime', e.target.value)}
                  placeholder="e.g., 2-3 hours"
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Challenge Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={8}
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                placeholder="Provide a detailed description of the challenge..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Starter Code
              </label>
              <textarea
                value={formData.starterCode}
                onChange={(e) => handleInputChange('starterCode', e.target.value)}
                rows={10}
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth font-mono text-sm"
                placeholder="// Provide starter code template..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Submission Requirements
              </label>
              <textarea
                value={formData.submissionRequirements}
                onChange={(e) => handleInputChange('submissionRequirements', e.target.value)}
                rows={6}
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                placeholder="List the requirements for submission..."
              />
            </div>
          </div>
        )}

        {activeTab === 'assignment' && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Minimum Experience Required
              </label>
              <input
                type="text"
                value={formData.assignmentRules.minExperience}
                onChange={(e) => handleNestedInputChange('assignmentRules', 'minExperience', e.target.value)}
                placeholder="e.g., 2 years"
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Required Skills (comma-separated)
              </label>
              <input
                type="text"
                value={formData.assignmentRules.requiredSkills.join(', ')}
                onChange={(e) => handleNestedInputChange('assignmentRules', 'requiredSkills', e.target.value.split(', ').filter(s => s.trim()))}
                placeholder="React, TypeScript, Testing"
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Excluded Skills (comma-separated)
              </label>
              <input
                type="text"
                value={formData.assignmentRules.excludeSkills.join(', ')}
                onChange={(e) => handleNestedInputChange('assignmentRules', 'excludeSkills', e.target.value.split(', ').filter(s => s.trim()))}
                placeholder="Skills to exclude from assignment"
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
              />
            </div>
          </div>
        )}

        {activeTab === 'evaluation' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Code Quality (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.evaluationCriteria.codeQuality}
                  onChange={(e) => handleNestedInputChange('evaluationCriteria', 'codeQuality', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Functionality (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.evaluationCriteria.functionality}
                  onChange={(e) => handleNestedInputChange('evaluationCriteria', 'functionality', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Testing (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.evaluationCriteria.testing}
                  onChange={(e) => handleNestedInputChange('evaluationCriteria', 'testing', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Documentation (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.evaluationCriteria.documentation}
                  onChange={(e) => handleNestedInputChange('evaluationCriteria', 'documentation', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                />
              </div>
            </div>

            <div className="bg-secondary-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Info" size={16} className="text-accent" />
                <span className="text-sm font-medium text-text-primary">Total Weight</span>
              </div>
              <p className="text-sm text-text-secondary">
                Current total: {Object.values(formData.evaluationCriteria).reduce((sum, val) => sum + val, 0)}%
                {Object.values(formData.evaluationCriteria).reduce((sum, val) => sum + val, 0) !== 100 && (
                  <span className="text-warning ml-2">⚠ Should equal 100%</span>
                )}
              </p>
            </div>
          </div>
        )}

        {activeTab === 'template' && (
          <div className="space-y-6">
            <div className="bg-accent-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="GitBranch" size={16} className="text-accent" />
                <span className="text-sm font-medium text-text-primary">Git Repository Template</span>
              </div>
              <p className="text-sm text-text-secondary">
                Configure the template repository structure and initial files that candidates will fork for their submissions.
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Repository Name Template
              </label>
              <input
                type="text"
                value="challenge-{challenge-id}-{candidate-name}"
                readOnly
                className="w-full px-3 py-2 border border-border rounded-lg bg-secondary-50 text-text-secondary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                README Template
              </label>
              <textarea
                rows={10}
                value={`# ${formData.title}

## Challenge Description
${formData.description}

## Requirements
${formData.submissionRequirements}

## Getting Started
1. Fork this repository
2. Clone your fork locally
3. Install dependencies
4. Start coding!

## Submission
1. Complete the challenge requirements
2. Commit your changes with clear messages
3. Push to your fork
4. Submit the repository URL

## Evaluation Criteria
- Code Quality: ${formData.evaluationCriteria.codeQuality}%
- Functionality: ${formData.evaluationCriteria.functionality}%
- Testing: ${formData.evaluationCriteria.testing}%
- Documentation: ${formData.evaluationCriteria.documentation}%

Good luck! 🚀`}
                readOnly
                className="w-full px-3 py-2 border border-border rounded-lg bg-secondary-50 text-text-secondary font-mono text-sm"
              />
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-surface rounded-lg p-6 max-w-md w-full mx-4 shadow-modal">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-error-100 rounded-full flex items-center justify-center">
                <Icon name="AlertTriangle" size={20} className="text-error" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-text-primary">Delete Challenge</h3>
                <p className="text-sm text-text-secondary">This action cannot be undone</p>
              </div>
            </div>
            
            <p className="text-text-secondary mb-6">
              Are you sure you want to delete "{formData.title}"? This will permanently remove the challenge and all associated data.
            </p>
            
            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-secondary-50 transition-smooth min-h-touch"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-error text-white rounded-lg hover:bg-error-600 transition-smooth min-h-touch"
              >
                Delete Challenge
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChallengeEditor;