import React from 'react';
import Icon from 'components/AppIcon';

const ChallengeList = ({
  challenges,
  selectedChallenge,
  onChallengeSelect,
  searchTerm,
  onSearchChange,
  difficultyFilter,
  onDifficultyFilterChange,
  isLoading,
  isMobile = false
}) => {
  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'beginner':
        return 'bg-success-100 text-success-700';
      case 'intermediate':
        return 'bg-warning-100 text-warning-700';
      case 'advanced':
        return 'bg-error-100 text-error-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'published':
        return 'bg-success-100 text-success-700';
      case 'draft':
        return 'bg-warning-100 text-warning-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const formatDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  if (isLoading) {
    return (
      <div className="bg-surface rounded-lg border border-border h-full">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-10 bg-secondary-100 rounded"></div>
            <div className="h-10 bg-secondary-100 rounded"></div>
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-20 bg-secondary-100 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-surface rounded-lg border border-border ${isMobile ? 'h-full' : ''}`}>
      {/* Search and Filters */}
      <div className="p-6 border-b border-border-light">
        <div className="space-y-4">
          <div className="relative">
            <Icon 
              name="Search" 
              size={20} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted" 
            />
            <input
              type="text"
              placeholder="Search challenges..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
            />
          </div>
          
          <select
            value={difficultyFilter}
            onChange={(e) => onDifficultyFilterChange(e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
          >
            <option value="all">All Difficulties</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>
        </div>
      </div>

      {/* Challenge List */}
      <div className={`${isMobile ? 'h-full overflow-y-auto pb-20' : 'max-h-96 overflow-y-auto'}`}>
        {challenges.length === 0 ? (
          <div className="p-6 text-center">
            <Icon name="FileText" size={48} className="text-text-muted mx-auto mb-3" />
            <p className="text-text-secondary">No challenges found</p>
            <p className="text-sm text-text-muted mt-1">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="divide-y divide-border-light">
            {challenges.map((challenge) => (
              <button
                key={challenge.id}
                onClick={() => onChallengeSelect(challenge)}
                className={`w-full text-left p-4 hover:bg-secondary-50 transition-smooth ${
                  selectedChallenge?.id === challenge.id ? 'bg-primary-50 border-r-2 border-primary-500' : ''
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <h3 className="font-medium text-text-primary line-clamp-2 flex-1">
                      {challenge.title}
                    </h3>
                    <div className="flex items-center space-x-2 ml-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(challenge.status)}`}>
                        {challenge.status}
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-text-secondary line-clamp-2">
                    {challenge.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(challenge.difficulty)}`}>
                        {challenge.difficulty}
                      </span>
                      <span className="text-xs text-text-muted">
                        {challenge.estimatedTime}
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-xs text-text-muted">
                      <div className="flex items-center space-x-1">
                        <Icon name="Users" size={12} />
                        <span>{challenge.assignedCount}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Icon name="CheckCircle" size={12} />
                        <span>{challenge.completedCount}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-text-muted">
                    <span>Updated {formatDate(challenge.updatedAt)}</span>
                    <span className="bg-secondary-100 text-secondary-700 px-2 py-1 rounded">
                      {challenge.category}
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChallengeList;