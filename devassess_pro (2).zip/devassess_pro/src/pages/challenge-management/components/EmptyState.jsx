import React from 'react';
import Icon from 'components/AppIcon';

const EmptyState = ({ onNewChallenge }) => {
  return (
    <div className="bg-surface rounded-lg border border-border h-full flex items-center justify-center">
      <div className="text-center py-12 px-6">
        <div className="w-24 h-24 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Icon name="FileText" size={48} className="text-secondary-400" />
        </div>
        
        <h3 className="text-xl font-semibold text-text-primary mb-2">
          No Challenge Selected
        </h3>
        
        <p className="text-text-secondary mb-8 max-w-md">
          Select a challenge from the list to edit its details, or create a new challenge to get started with your recruitment process.
        </p>
        
        <div className="space-y-3">
          <button
            onClick={onNewChallenge}
            className="inline-flex items-center space-x-2 bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition-smooth min-h-touch"
          >
            <Icon name="Plus" size={20} />
            <span>Create New Challenge</span>
          </button>
          
          <div className="text-sm text-text-muted">
            or select an existing challenge from the left panel
          </div>
        </div>
        
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6 text-left">
          <div className="space-y-2">
            <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center">
              <Icon name="Edit" size={16} className="text-primary-600" />
            </div>
            <h4 className="font-medium text-text-primary">Create & Edit</h4>
            <p className="text-sm text-text-secondary">
              Build comprehensive coding challenges with detailed requirements and evaluation criteria.
            </p>
          </div>
          
          <div className="space-y-2">
            <div className="w-8 h-8 bg-success-100 rounded-lg flex items-center justify-center">
              <Icon name="Users" size={16} className="text-success-600" />
            </div>
            <h4 className="font-medium text-text-primary">Assign Candidates</h4>
            <p className="text-sm text-text-secondary">
              Set assignment rules and criteria to automatically match challenges with suitable candidates.
            </p>
          </div>
          
          <div className="space-y-2">
            <div className="w-8 h-8 bg-accent-100 rounded-lg flex items-center justify-center">
              <Icon name="BarChart3" size={16} className="text-accent-600" />
            </div>
            <h4 className="font-medium text-text-primary">Track Progress</h4>
            <p className="text-sm text-text-secondary">
              Monitor challenge completion rates and candidate performance metrics in real-time.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmptyState;