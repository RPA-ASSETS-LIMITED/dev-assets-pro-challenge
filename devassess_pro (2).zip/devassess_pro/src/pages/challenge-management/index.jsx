import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import RoleBasedNavigation from 'components/ui/RoleBasedNavigation';
import BreadcrumbNavigation from 'components/ui/BreadcrumbNavigation';
import ChallengeList from './components/ChallengeList';
import ChallengeEditor from './components/ChallengeEditor';
import EmptyState from './components/EmptyState';

const ChallengeManagement = () => {
  const [selectedChallenge, setSelectedChallenge] = useState(null);
  const [challenges, setChallenges] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState('all');
  const [isMobileListOpen, setIsMobileListOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Mock challenges data
  const mockChallenges = [
    {
      id: 1,
      title: "React Component Architecture",
      description: `Build a scalable React component library with proper TypeScript definitions and comprehensive testing suite. This challenge focuses on creating reusable components that follow modern React patterns including hooks, context, and performance optimization techniques.

You'll need to implement a component system that includes form elements, data display components, and interactive widgets. Pay special attention to accessibility standards and responsive design principles.`,
      difficulty: "intermediate",
      estimatedTime: "4-6 hours",
      category: "Frontend",
      status: "published",
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      assignedCount: 12,
      completedCount: 8,
      starterCode: `import React from 'react';

// Your component implementation here
const MyComponent = () => {
  return (
    <div>
      {/* Implement your solution */}
    </div>
  );
};

export default MyComponent;`,
      submissionRequirements: `1. Complete component implementation with TypeScript
2. Unit tests with Jest and React Testing Library
3. Storybook documentation for all components
4. README with setup and usage instructions
5. Git repository with clear commit history`,
      evaluationCriteria: {
        codeQuality: 30,
        functionality: 25,
        testing: 20,
        documentation: 15,
        performance: 10
      },
      assignmentRules: {
        minExperience: "2 years",
        requiredSkills: ["React", "TypeScript", "Testing"],
        excludeSkills: []
      }
    },
    {
      id: 2,
      title: "Full Stack E-commerce API",
      description: `Design and implement a RESTful API for an e-commerce platform using Node.js and Express. The API should handle user authentication, product management, shopping cart functionality, and order processing with proper error handling and validation.

Focus on creating a well-structured, scalable backend that follows REST principles and includes comprehensive API documentation. Implement proper security measures including authentication, authorization, and data validation.`,
      difficulty: "advanced",
      estimatedTime: "8-10 hours",
      category: "Backend",
      status: "draft",
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      assignedCount: 5,
      completedCount: 2,
      starterCode: `const express = require('express');
const app = express();

// Middleware setup
app.use(express.json());

// Your API routes here

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});`,
      submissionRequirements: `1. Complete API implementation with all endpoints
2. Database schema and migrations
3. Authentication and authorization system
4. API documentation (Swagger/OpenAPI)
5. Unit and integration tests
6. Docker configuration for deployment`,
      evaluationCriteria: {
        apiDesign: 25,
        codeQuality: 25,
        security: 20,
        testing: 15,
        documentation: 15
      },
      assignmentRules: {
        minExperience: "3 years",
        requiredSkills: ["Node.js", "Express", "Database", "API Design"],
        excludeSkills: []
      }
    },
    {
      id: 3,
      title: "CSS Grid Layout Challenge",
      description: `Create a responsive web layout using CSS Grid and Flexbox that adapts seamlessly across desktop, tablet, and mobile devices. The layout should include a header, navigation, main content area, sidebar, and footer with proper spacing and alignment.

Demonstrate mastery of modern CSS layout techniques including grid areas, responsive design patterns, and accessibility considerations. The design should be pixel-perfect and work across all modern browsers.`,
      difficulty: "beginner",
      estimatedTime: "2-3 hours",
      category: "Frontend",
      status: "published",
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
      assignedCount: 25,
      completedCount: 20,
      starterCode: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSS Grid Layout</title>
    <style>
        /* Your CSS implementation here */
    </style>
</head>
<body>
    <!-- Your HTML structure here -->
</body>
</html>`,
      submissionRequirements: `1. Complete HTML structure with semantic elements
2. CSS Grid and Flexbox implementation
3. Responsive design for mobile, tablet, desktop
4. Cross-browser compatibility
5. Accessibility features (ARIA labels, keyboard navigation)
6. Clean, well-commented code`,
      evaluationCriteria: {
        layoutImplementation: 35,
        responsiveDesign: 25,
        codeQuality: 20,
        accessibility: 20
      },
      assignmentRules: {
        minExperience: "1 year",
        requiredSkills: ["CSS", "HTML", "Responsive Design"],
        excludeSkills: []
      }
    }
  ];

  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      setChallenges(mockChallenges);
      setIsLoading(false);
    }, 1000);
  }, []);

  const filteredChallenges = challenges.filter(challenge => {
    const matchesSearch = challenge.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         challenge.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDifficulty = difficultyFilter === 'all' || challenge.difficulty === difficultyFilter;
    return matchesSearch && matchesDifficulty;
  });

  const handleChallengeSelect = (challenge) => {
    setSelectedChallenge(challenge);
    setIsMobileListOpen(false);
  };

  const handleChallengeUpdate = (updatedChallenge) => {
    setChallenges(prev => 
      prev.map(challenge => 
        challenge.id === updatedChallenge.id ? updatedChallenge : challenge
      )
    );
    setSelectedChallenge(updatedChallenge);
  };

  const handleChallengeDelete = (challengeId) => {
    setChallenges(prev => prev.filter(challenge => challenge.id !== challengeId));
    if (selectedChallenge && selectedChallenge.id === challengeId) {
      setSelectedChallenge(null);
    }
  };

  const handleNewChallenge = () => {
    const newChallenge = {
      id: Date.now(),
      title: "New Challenge",
      description: "Enter challenge description here...",
      difficulty: "beginner",
      estimatedTime: "2-3 hours",
      category: "Frontend",
      status: "draft",
      createdAt: new Date(),
      updatedAt: new Date(),
      assignedCount: 0,
      completedCount: 0,
      starterCode: "// Your starter code here",
      submissionRequirements: "1. Complete implementation\n2. Unit tests\n3. Documentation",
      evaluationCriteria: {
        codeQuality: 40,
        functionality: 30,
        testing: 20,
        documentation: 10
      },
      assignmentRules: {
        minExperience: "1 year",
        requiredSkills: [],
        excludeSkills: []
      }
    };
    setChallenges(prev => [newChallenge, ...prev]);
    setSelectedChallenge(newChallenge);
  };

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedNavigation userRole="admin" currentPath="/challenge-management" />
      <BreadcrumbNavigation currentPath="/challenge-management" userRole="admin" />
      
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-text-primary mb-2">Challenge Management</h1>
            <p className="text-text-secondary">Create, edit, and organize coding challenges for your recruitment process</p>
          </div>
          <div className="mt-4 sm:mt-0 flex items-center space-x-3">
            <button
              onClick={handleNewChallenge}
              className="inline-flex items-center space-x-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-smooth min-h-touch"
            >
              <Icon name="Plus" size={20} />
              <span>New Challenge</span>
            </button>
            <button
              onClick={() => setIsMobileListOpen(true)}
              className="md:hidden inline-flex items-center space-x-2 bg-secondary-100 text-secondary-700 px-4 py-2 rounded-lg hover:bg-secondary-200 transition-smooth min-h-touch"
            >
              <Icon name="List" size={20} />
              <span>Challenges</span>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-surface rounded-lg p-6 shadow-card border border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-text-secondary text-sm font-medium">Total Challenges</p>
                <p className="text-2xl font-bold text-text-primary">{challenges.length}</p>
              </div>
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
                <Icon name="FileText" size={24} className="text-primary-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-surface rounded-lg p-6 shadow-card border border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-text-secondary text-sm font-medium">Published</p>
                <p className="text-2xl font-bold text-text-primary">
                  {challenges.filter(c => c.status === 'published').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-success-100 rounded-lg flex items-center justify-center">
                <Icon name="CheckCircle" size={24} className="text-success-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-surface rounded-lg p-6 shadow-card border border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-text-secondary text-sm font-medium">Draft</p>
                <p className="text-2xl font-bold text-text-primary">
                  {challenges.filter(c => c.status === 'draft').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-warning-100 rounded-lg flex items-center justify-center">
                <Icon name="Edit" size={24} className="text-warning-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-surface rounded-lg p-6 shadow-card border border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-text-secondary text-sm font-medium">Total Assignments</p>
                <p className="text-2xl font-bold text-text-primary">
                  {challenges.reduce((sum, c) => sum + c.assignedCount, 0)}
                </p>
              </div>
              <div className="w-12 h-12 bg-accent-100 rounded-lg flex items-center justify-center">
                <Icon name="Users" size={24} className="text-accent-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Challenge List - Desktop */}
          <div className="hidden lg:block lg:col-span-4">
            <ChallengeList
              challenges={filteredChallenges}
              selectedChallenge={selectedChallenge}
              onChallengeSelect={handleChallengeSelect}
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              difficultyFilter={difficultyFilter}
              onDifficultyFilterChange={setDifficultyFilter}
              isLoading={isLoading}
            />
          </div>

          {/* Challenge Editor */}
          <div className="lg:col-span-8">
            {selectedChallenge ? (
              <ChallengeEditor
                challenge={selectedChallenge}
                onUpdate={handleChallengeUpdate}
                onDelete={handleChallengeDelete}
              />
            ) : (
              <EmptyState onNewChallenge={handleNewChallenge} />
            )}
          </div>
        </div>

        {/* Mobile Challenge List Modal */}
        {isMobileListOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 lg:hidden">
            <div className="fixed inset-y-0 left-0 w-full max-w-sm bg-surface shadow-modal">
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h2 className="text-lg font-semibold text-text-primary">Challenges</h2>
                <button
                  onClick={() => setIsMobileListOpen(false)}
                  className="p-2 text-text-secondary hover:text-text-primary transition-smooth min-h-touch min-w-touch"
                >
                  <Icon name="X" size={20} />
                </button>
              </div>
              <div className="h-full overflow-hidden">
                <ChallengeList
                  challenges={filteredChallenges}
                  selectedChallenge={selectedChallenge}
                  onChallengeSelect={handleChallengeSelect}
                  searchTerm={searchTerm}
                  onSearchChange={setSearchTerm}
                  difficultyFilter={difficultyFilter}
                  onDifficultyFilterChange={setDifficultyFilter}
                  isLoading={isLoading}
                  isMobile={true}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChallengeManagement;