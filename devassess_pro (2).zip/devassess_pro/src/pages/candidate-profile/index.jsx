import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import RoleBasedNavigation from 'components/ui/RoleBasedNavigation';
import BreadcrumbNavigation from 'components/ui/BreadcrumbNavigation';
import CandidateCard from './components/CandidateCard';
import AssessmentHistory from './components/AssessmentHistory';
import PerformanceCharts from './components/PerformanceCharts';
import ActionButtons from './components/ActionButtons';
import NotesSection from './components/NotesSection';

const CandidateProfile = () => {
  const [currentUserRole] = useState('recruiter');
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [filterOptions, setFilterOptions] = useState({
    sortBy: 'date',
    difficulty: 'all',
    status: 'all'
  });

  // Mock candidate data
  const candidateData = {
    id: 'CAND-001',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@email.com',
    registrationDate: '2024-01-15',
    profileImage: 'https://randomuser.me/api/portraits/women/32.jpg',
    overallScore: 87,
    completionRate: 92,
    averageTime: '2.5 hours',
    totalChallenges: 12,
    completedChallenges: 11,
    skills: ['React', 'JavaScript', 'Node.js', 'Python', 'SQL', 'Git'],
    location: 'San Francisco, CA',
    experience: '3 years',
    education: 'BS Computer Science',
    githubProfile: 'https://github.com/sarahjohnson',
    linkedinProfile: 'https://linkedin.com/in/sarahjohnson',
    phone: '+1 (555) 123-4567',
    status: 'Active'
  };

  const assessmentHistory = [
    {
      id: 1,
      challengeName: 'React Component Architecture',
      difficulty: 'Advanced',
      submissionDate: '2024-03-15',
      completionTime: '3.2 hours',
      score: 94,
      status: 'Completed',
      feedback: 'Excellent component structure and state management',
      githubLink: 'https://github.com/sarahjohnson/react-architecture',
      reviewerNotes: `Outstanding implementation of component architecture patterns. Demonstrated excellent understanding of React hooks, context API, and performance optimization techniques.

The solution shows clean code organization with proper separation of concerns and reusable component design.`
    },
    {
      id: 2,
      challengeName: 'Full Stack E-commerce API',
      difficulty: 'Expert',
      submissionDate: '2024-03-10',
      completionTime: '4.8 hours',
      score: 89,
      status: 'Completed',
      feedback: 'Strong backend implementation with room for frontend polish',
      githubLink: 'https://github.com/sarahjohnson/ecommerce-api',
      reviewerNotes: `Solid full-stack implementation with comprehensive API design. Authentication and authorization properly implemented with JWT tokens.

Database schema is well-designed with appropriate relationships and indexing strategies.`
    },
    {
      id: 3,
      challengeName: 'Algorithm Optimization',
      difficulty: 'Intermediate',
      submissionDate: '2024-03-05',
      completionTime: '2.1 hours',
      score: 91,
      status: 'Completed',
      feedback: 'Efficient algorithms with clear documentation',
      githubLink: 'https://github.com/sarahjohnson/algorithm-optimization',
      reviewerNotes: `Excellent problem-solving approach with multiple solution strategies. Code is well-documented with time and space complexity analysis.

Shows strong understanding of data structures and algorithmic thinking.`
    },
    {
      id: 4,
      challengeName: 'Database Design Challenge',
      difficulty: 'Advanced',
      submissionDate: '2024-02-28',
      completionTime: '3.5 hours',
      score: 85,
      status: 'Completed',
      feedback: 'Good database design with minor optimization opportunities',
      githubLink: 'https://github.com/sarahjohnson/database-design',
      reviewerNotes: `Comprehensive database design with proper normalization and relationship modeling. Query optimization could be improved for better performance.

Understanding of indexing strategies and transaction management is evident.`
    },
    {
      id: 5,
      challengeName: 'Frontend Performance Optimization',
      difficulty: 'Advanced',
      submissionDate: '2024-02-20',
      completionTime: '2.8 hours',
      score: 88,
      status: 'Completed',
      feedback: 'Great performance improvements and modern techniques',
      githubLink: 'https://github.com/sarahjohnson/frontend-optimization',
      reviewerNotes: `Impressive performance optimization techniques including code splitting, lazy loading, and bundle optimization.

Demonstrates understanding of modern frontend build tools and performance monitoring.`
    }
  ];

  const performanceData = {
    completionRateData: [
      { month: 'Jan', rate: 85 },
      { month: 'Feb', rate: 90 },
      { month: 'Mar', rate: 92 }
    ],
    difficultyProgression: [
      { difficulty: 'Beginner', completed: 3, total: 3 },
      { difficulty: 'Intermediate', completed: 4, total: 4 },
      { difficulty: 'Advanced', completed: 3, total: 4 },
      { difficulty: 'Expert', completed: 1, total: 1 }
    ],
    timeToCompletion: [
      { challenge: 'React Basics', time: 1.5 },
      { challenge: 'API Integration', time: 2.2 },
      { challenge: 'Database Design', time: 3.5 },
      { challenge: 'Full Stack', time: 4.8 }
    ]
  };

  const recruiterNotes = [
    {
      id: 1,
      author: 'Mike Rodriguez',
      date: '2024-03-16',
      note: `Sarah demonstrates exceptional technical skills and problem-solving abilities. Her React architecture challenge submission was outstanding, showing deep understanding of modern development patterns.

Recommended for senior-level positions. Strong communication skills during technical discussions.`,
      type: 'evaluation'
    },
    {
      id: 2,
      author: 'Lisa Chen',
      date: '2024-03-12',
      note: `Follow-up scheduled for next week to discuss full-stack developer role. Candidate expressed interest in remote work opportunities.

Technical skills align well with our current project requirements.`,
      type: 'follow-up'
    },
    {
      id: 3,
      author: 'David Kim',
      date: '2024-03-08',
      note: `Initial screening completed. Candidate has strong GitHub portfolio and active open-source contributions. 

Background check initiated. References provided are from previous technical leads.`,
      type: 'screening'
    }
  ];

  useEffect(() => {
    setSelectedCandidate(candidateData);
  }, []);

  const handleFilterChange = (filterType, value) => {
    setFilterOptions(prev => ({
      ...prev,
      [filterType]: value
    }));
  };

  const filteredAssessments = assessmentHistory.filter(assessment => {
    if (filterOptions.difficulty !== 'all' && assessment.difficulty !== filterOptions.difficulty) {
      return false;
    }
    if (filterOptions.status !== 'all' && assessment.status !== filterOptions.status) {
      return false;
    }
    return true;
  }).sort((a, b) => {
    switch (filterOptions.sortBy) {
      case 'date':
        return new Date(b.submissionDate) - new Date(a.submissionDate);
      case 'score':
        return b.score - a.score;
      case 'difficulty':
        const difficultyOrder = { 'Beginner': 1, 'Intermediate': 2, 'Advanced': 3, 'Expert': 4 };
        return difficultyOrder[b.difficulty] - difficultyOrder[a.difficulty];
      default:
        return 0;
    }
  });

  if (!selectedCandidate) {
    return (
      <div className="min-h-screen bg-background">
        <RoleBasedNavigation userRole={currentUserRole} currentPath="/candidate-profile" />
        <BreadcrumbNavigation currentPath="/candidate-profile" userRole={currentUserRole} />
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Icon name="Loader2" size={48} className="text-primary animate-spin mx-auto mb-4" />
            <p className="text-text-secondary">Loading candidate profile...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedNavigation userRole={currentUserRole} currentPath="/candidate-profile" />
      <BreadcrumbNavigation currentPath="/candidate-profile" userRole={currentUserRole} />
      
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-text-primary mb-2">Candidate Profile</h1>
              <p className="text-text-secondary">Comprehensive performance tracking and assessment history</p>
            </div>
            <ActionButtons candidate={selectedCandidate} />
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column - Candidate Summary */}
          <div className="lg:col-span-4 space-y-6">
            <CandidateCard candidate={selectedCandidate} />
            <PerformanceCharts data={performanceData} />
            <NotesSection notes={recruiterNotes} candidateId={selectedCandidate.id} />
          </div>

          {/* Right Column - Assessment History */}
          <div className="lg:col-span-8">
            <AssessmentHistory 
              assessments={filteredAssessments}
              filterOptions={filterOptions}
              onFilterChange={handleFilterChange}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateProfile;