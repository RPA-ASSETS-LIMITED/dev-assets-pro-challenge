import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const NotesSection = ({ notes, candidateId }) => {
  const [newNote, setNewNote] = useState('');
  const [noteType, setNoteType] = useState('evaluation');
  const [isAddingNote, setIsAddingNote] = useState(false);

  const getTypeColor = (type) => {
    switch (type) {
      case 'evaluation':
        return 'bg-primary-100 text-primary-700';
      case 'follow-up':
        return 'bg-warning-100 text-warning-700';
      case 'screening':
        return 'bg-success-100 text-success-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'evaluation':
        return 'Star';
      case 'follow-up':
        return 'Clock';
      case 'screening':
        return 'CheckCircle';
      default:
        return 'FileText';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleAddNote = () => {
    if (newNote.trim()) {
      const note = {
        id: Date.now(),
        author: 'Current User',
        date: new Date().toISOString().split('T')[0],
        note: newNote,
        type: noteType
      };
      
      console.log('Adding note for candidate:', candidateId, note);
      setNewNote('');
      setNoteType('evaluation');
      setIsAddingNote(false);
      // Show success notification
      alert('Note added successfully!');
    }
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="FileText" size={20} className="text-text-secondary" />
          <h3 className="text-lg font-semibold text-text-primary">Recruiter Notes</h3>
        </div>
        <button
          onClick={() => setIsAddingNote(true)}
          className="inline-flex items-center space-x-1 px-3 py-1 text-sm text-primary-600 hover:text-primary-700 border border-primary-200 hover:border-primary-300 rounded-md transition-smooth"
        >
          <Icon name="Plus" size={14} />
          <span>Add Note</span>
        </button>
      </div>

      {/* Add Note Form */}
      {isAddingNote && (
        <div className="mb-6 p-4 bg-secondary-50 rounded-lg border border-border-light">
          <div className="mb-3">
            <label className="block text-sm font-medium text-text-primary mb-2">
              Note Type
            </label>
            <select
              value={noteType}
              onChange={(e) => setNoteType(e.target.value)}
              className="w-full px-3 py-2 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="evaluation">Evaluation</option>
              <option value="follow-up">Follow-up</option>
              <option value="screening">Screening</option>
            </select>
          </div>
          
          <div className="mb-3">
            <label className="block text-sm font-medium text-text-primary mb-2">
              Note Content
            </label>
            <textarea
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              placeholder="Enter your note here..."
              rows={3}
              className="w-full px-3 py-2 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 resize-none"
            />
          </div>
          
          <div className="flex items-center justify-end space-x-2">
            <button
              onClick={() => {
                setIsAddingNote(false);
                setNewNote('');
                setNoteType('evaluation');
              }}
              className="px-3 py-1 text-sm text-text-secondary hover:text-text-primary border border-border rounded-md hover:bg-secondary-50 transition-smooth"
            >
              Cancel
            </button>
            <button
              onClick={handleAddNote}
              disabled={!newNote.trim()}
              className="px-3 py-1 text-sm bg-primary text-white rounded-md hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth"
            >
              Add Note
            </button>
          </div>
        </div>
      )}

      {/* Notes List */}
      <div className="space-y-4">
        {notes.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="FileText" size={48} className="text-text-muted mx-auto mb-3" />
            <p className="text-text-secondary">No notes yet</p>
            <p className="text-sm text-text-muted">Add your first note to track candidate progress</p>
          </div>
        ) : (
          notes.map((note) => (
            <div key={note.id} className="border border-border-light rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <Icon name={getTypeIcon(note.type)} size={16} className="text-text-muted" />
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(note.type)}`}>
                    {note.type.charAt(0).toUpperCase() + note.type.slice(1)}
                  </span>
                </div>
                <div className="text-sm text-text-muted">
                  {formatDate(note.date)}
                </div>
              </div>
              
              <div className="mb-2">
                <p className="text-sm font-medium text-text-primary">{note.author}</p>
              </div>
              
              <div className="text-sm text-text-secondary whitespace-pre-line">
                {note.note}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default NotesSection;