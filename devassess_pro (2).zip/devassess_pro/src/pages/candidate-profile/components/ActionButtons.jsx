import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const ActionButtons = ({ candidate }) => {
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [selectedChallenge, setSelectedChallenge] = useState('');
  const [messageContent, setMessageContent] = useState('');

  const availableChallenges = [
    { id: 1, name: 'Advanced React Patterns', difficulty: 'Advanced' },
    { id: 2, name: 'System Design Challenge', difficulty: 'Expert' },
    { id: 3, name: 'GraphQL API Development', difficulty: 'Advanced' },
    { id: 4, name: 'Microservices Architecture', difficulty: 'Expert' }
  ];

  const handleAssignChallenge = () => {
    if (selectedChallenge) {
      console.log('Assigning challenge:', selectedChallenge, 'to candidate:', candidate.id);
      setShowAssignModal(false);
      setSelectedChallenge('');
      // Show success notification
      alert('Challenge assigned successfully!');
    }
  };

  const handleSendMessage = () => {
    if (messageContent.trim()) {
      console.log('Sending message to candidate:', candidate.id, 'Message:', messageContent);
      setShowMessageModal(false);
      setMessageContent('');
      // Show success notification
      alert('Message sent successfully!');
    }
  };

  const handleExportReport = () => {
    console.log('Exporting report for candidate:', candidate.id);
    // Simulate report generation
    const reportData = {
      candidateName: candidate.name,
      overallScore: candidate.overallScore,
      completionRate: candidate.completionRate,
      exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(reportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${candidate.name.replace(/\s+/g, '_')}_Report.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  return (
    <>
      <div className="flex items-center space-x-3">
        <button
          onClick={() => setShowAssignModal(true)}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-smooth min-h-touch"
        >
          <Icon name="Plus" size={16} />
          <span>Assign Challenge</span>
        </button>
        
        <button
          onClick={() => setShowMessageModal(true)}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-accent text-white rounded-lg hover:bg-accent-700 focus:outline-none focus:ring-2 focus:ring-accent-500 focus:ring-offset-2 transition-smooth min-h-touch"
        >
          <Icon name="MessageSquare" size={16} />
          <span>Send Message</span>
        </button>
        
        <button
          onClick={handleExportReport}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-success text-white rounded-lg hover:bg-success-600 focus:outline-none focus:ring-2 focus:ring-success-500 focus:ring-offset-2 transition-smooth min-h-touch"
        >
          <Icon name="Download" size={16} />
          <span>Export Report</span>
        </button>
      </div>

      {/* Assign Challenge Modal */}
      {showAssignModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1020 p-4">
          <div className="bg-surface rounded-lg shadow-modal max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text-primary">Assign New Challenge</h3>
              <button
                onClick={() => setShowAssignModal(false)}
                className="p-2 text-text-secondary hover:text-text-primary transition-smooth min-h-touch min-w-touch"
              >
                <Icon name="X" size={20} />
              </button>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-text-primary mb-2">
                Select Challenge
              </label>
              <select
                value={selectedChallenge}
                onChange={(e) => setSelectedChallenge(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="">Choose a challenge...</option>
                {availableChallenges.map((challenge) => (
                  <option key={challenge.id} value={challenge.id}>
                    {challenge.name} ({challenge.difficulty})
                  </option>
                ))}
              </select>
            </div>
            
            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => setShowAssignModal(false)}
                className="px-4 py-2 text-text-secondary hover:text-text-primary border border-border rounded-lg hover:bg-secondary-50 transition-smooth min-h-touch"
              >
                Cancel
              </button>
              <button
                onClick={handleAssignChallenge}
                disabled={!selectedChallenge}
                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth min-h-touch"
              >
                Assign Challenge
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Send Message Modal */}
      {showMessageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1020 p-4">
          <div className="bg-surface rounded-lg shadow-modal max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text-primary">Send Message</h3>
              <button
                onClick={() => setShowMessageModal(false)}
                className="p-2 text-text-secondary hover:text-text-primary transition-smooth min-h-touch min-w-touch"
              >
                <Icon name="X" size={20} />
              </button>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-text-primary mb-2">
                Message to {candidate.name}
              </label>
              <textarea
                value={messageContent}
                onChange={(e) => setMessageContent(e.target.value)}
                placeholder="Type your message here..."
                rows={4}
                className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 resize-none"
              />
            </div>
            
            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => setShowMessageModal(false)}
                className="px-4 py-2 text-text-secondary hover:text-text-primary border border-border rounded-lg hover:bg-secondary-50 transition-smooth min-h-touch"
              >
                Cancel
              </button>
              <button
                onClick={handleSendMessage}
                disabled={!messageContent.trim()}
                className="px-4 py-2 bg-accent text-white rounded-lg hover:bg-accent-700 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth min-h-touch"
              >
                Send Message
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ActionButtons;