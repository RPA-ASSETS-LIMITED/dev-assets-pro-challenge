import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const AssessmentHistory = ({ assessments, filterOptions, onFilterChange }) => {
  const [expandedAssessment, setExpandedAssessment] = useState(null);

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Beginner':
        return 'bg-success-100 text-success-700';
      case 'Intermediate':
        return 'bg-warning-100 text-warning-700';
      case 'Advanced':
        return 'bg-error-100 text-error-700';
      case 'Expert':
        return 'bg-primary-100 text-primary-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed':
        return 'bg-success-100 text-success-700';
      case 'In Progress':
        return 'bg-warning-100 text-warning-700';
      case 'Submitted':
        return 'bg-accent-100 text-accent-700';
      case 'Evaluated':
        return 'bg-primary-100 text-primary-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-success-600';
    if (score >= 80) return 'text-warning-600';
    if (score >= 70) return 'text-error-600';
    return 'text-text-secondary';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const toggleExpanded = (assessmentId) => {
    setExpandedAssessment(expandedAssessment === assessmentId ? null : assessmentId);
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border">
      {/* Header */}
      <div className="p-6 border-b border-border-light">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-text-primary">Assessment History</h2>
          <div className="text-sm text-text-secondary">
            {assessments.length} assessment{assessments.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-text-secondary">Sort by:</label>
            <select
              value={filterOptions.sortBy}
              onChange={(e) => onFilterChange('sortBy', e.target.value)}
              className="px-3 py-1 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="date">Date</option>
              <option value="score">Score</option>
              <option value="difficulty">Difficulty</option>
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-text-secondary">Difficulty:</label>
            <select
              value={filterOptions.difficulty}
              onChange={(e) => onFilterChange('difficulty', e.target.value)}
              className="px-3 py-1 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="all">All</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
              <option value="Expert">Expert</option>
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-text-secondary">Status:</label>
            <select
              value={filterOptions.status}
              onChange={(e) => onFilterChange('status', e.target.value)}
              className="px-3 py-1 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="all">All</option>
              <option value="Completed">Completed</option>
              <option value="In Progress">In Progress</option>
              <option value="Submitted">Submitted</option>
              <option value="Evaluated">Evaluated</option>
            </select>
          </div>
        </div>
      </div>

      {/* Assessment List */}
      <div className="divide-y divide-border-light">
        {assessments.length === 0 ? (
          <div className="p-8 text-center">
            <Icon name="FileText" size={48} className="text-text-muted mx-auto mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-2">No assessments found</h3>
            <p className="text-text-secondary">No assessments match the current filter criteria.</p>
          </div>
        ) : (
          assessments.map((assessment) => (
            <div key={assessment.id} className="p-6">
              {/* Desktop View */}
              <div className="hidden md:block">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-4">
                      <h3 className="text-lg font-medium text-text-primary truncate">
                        {assessment.challengeName}
                      </h3>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(assessment.difficulty)}`}>
                        {assessment.difficulty}
                      </span>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(assessment.status)}`}>
                        {assessment.status}
                      </span>
                    </div>
                    <div className="flex items-center space-x-6 mt-2 text-sm text-text-secondary">
                      <div className="flex items-center space-x-1">
                        <Icon name="Calendar" size={14} />
                        <span>{formatDate(assessment.submissionDate)}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Icon name="Clock" size={14} />
                        <span>{assessment.completionTime}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Icon name="Target" size={14} />
                        <span className={`font-medium ${getScoreColor(assessment.score)}`}>
                          {assessment.score}/100
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <a
                      href={assessment.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-1 px-3 py-1 text-sm text-primary-600 hover:text-primary-700 border border-primary-200 hover:border-primary-300 rounded-md transition-smooth"
                    >
                      <Icon name="Github" size={14} />
                      <span>View Code</span>
                      <Icon name="ExternalLink" size={12} />
                    </a>
                    <button
                      onClick={() => toggleExpanded(assessment.id)}
                      className="p-2 text-text-secondary hover:text-text-primary transition-smooth min-h-touch min-w-touch"
                    >
                      <Icon 
                        name={expandedAssessment === assessment.id ? "ChevronUp" : "ChevronDown"} 
                        size={16} 
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* Mobile View */}
              <div className="md:hidden">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-lg font-medium text-text-primary pr-4">
                    {assessment.challengeName}
                  </h3>
                  <button
                    onClick={() => toggleExpanded(assessment.id)}
                    className="p-2 text-text-secondary hover:text-text-primary transition-smooth min-h-touch min-w-touch"
                  >
                    <Icon 
                      name={expandedAssessment === assessment.id ? "ChevronUp" : "ChevronDown"} 
                      size={16} 
                    />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 mb-3">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(assessment.difficulty)}`}>
                    {assessment.difficulty}
                  </span>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(assessment.status)}`}>
                    {assessment.status}
                  </span>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary-100 ${getScoreColor(assessment.score)}`}>
                    {assessment.score}/100
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm text-text-secondary">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Icon name="Calendar" size={14} />
                      <span>{formatDate(assessment.submissionDate)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="Clock" size={14} />
                      <span>{assessment.completionTime}</span>
                    </div>
                  </div>
                  <a
                    href={assessment.githubLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-1 text-primary-600 hover:text-primary-700 transition-smooth"
                  >
                    <Icon name="Github" size={14} />
                    <Icon name="ExternalLink" size={12} />
                  </a>
                </div>
              </div>

              {/* Expanded Details */}
              {expandedAssessment === assessment.id && (
                <div className="mt-4 pt-4 border-t border-border-light">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-sm font-medium text-text-primary mb-2">Feedback</h4>
                      <p className="text-sm text-text-secondary mb-4">{assessment.feedback}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-text-primary mb-2">Reviewer Notes</h4>
                      <div className="text-sm text-text-secondary whitespace-pre-line">
                        {assessment.reviewerNotes}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AssessmentHistory;