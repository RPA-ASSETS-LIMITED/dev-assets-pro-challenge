import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const CandidateCard = ({ candidate }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-success-100 text-success-700';
      case 'Inactive':
        return 'bg-secondary-100 text-secondary-700';
      case 'Pending':
        return 'bg-warning-100 text-warning-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border p-6">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full overflow-hidden bg-secondary-100">
              <Image 
                src={candidate.profileImage} 
                alt={candidate.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-surface ${
              candidate.status === 'Active' ? 'bg-success' : 'bg-secondary-400'
            }`}></div>
          </div>
          <div>
            <h2 className="text-xl font-semibold text-text-primary">{candidate.name}</h2>
            <p className="text-text-secondary">{candidate.email}</p>
            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mt-2 ${getStatusColor(candidate.status)}`}>
              {candidate.status}
            </span>
          </div>
        </div>
      </div>

      {/* Contact Information */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center space-x-3 text-sm">
          <Icon name="MapPin" size={16} className="text-text-muted" />
          <span className="text-text-secondary">{candidate.location}</span>
        </div>
        <div className="flex items-center space-x-3 text-sm">
          <Icon name="Phone" size={16} className="text-text-muted" />
          <span className="text-text-secondary">{candidate.phone}</span>
        </div>
        <div className="flex items-center space-x-3 text-sm">
          <Icon name="Calendar" size={16} className="text-text-muted" />
          <span className="text-text-secondary">Joined {formatDate(candidate.registrationDate)}</span>
        </div>
        <div className="flex items-center space-x-3 text-sm">
          <Icon name="Briefcase" size={16} className="text-text-muted" />
          <span className="text-text-secondary">{candidate.experience} experience</span>
        </div>
        <div className="flex items-center space-x-3 text-sm">
          <Icon name="GraduationCap" size={16} className="text-text-muted" />
          <span className="text-text-secondary">{candidate.education}</span>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="border-t border-border-light pt-6 mb-6">
        <h3 className="text-sm font-medium text-text-primary mb-4">Performance Overview</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-primary-50 rounded-lg">
            <div className="text-2xl font-bold text-primary-700">{candidate.overallScore}</div>
            <div className="text-xs text-text-secondary">Overall Score</div>
          </div>
          <div className="text-center p-3 bg-success-50 rounded-lg">
            <div className="text-2xl font-bold text-success-700">{candidate.completionRate}%</div>
            <div className="text-xs text-text-secondary">Completion Rate</div>
          </div>
          <div className="text-center p-3 bg-accent-50 rounded-lg">
            <div className="text-2xl font-bold text-accent-700">{candidate.averageTime}</div>
            <div className="text-xs text-text-secondary">Avg. Time</div>
          </div>
          <div className="text-center p-3 bg-warning-50 rounded-lg">
            <div className="text-2xl font-bold text-warning-700">{candidate.completedChallenges}/{candidate.totalChallenges}</div>
            <div className="text-xs text-text-secondary">Challenges</div>
          </div>
        </div>
      </div>

      {/* Skills */}
      <div className="border-t border-border-light pt-6 mb-6">
        <h3 className="text-sm font-medium text-text-primary mb-3">Skills</h3>
        <div className="flex flex-wrap gap-2">
          {candidate.skills.map((skill, index) => (
            <span 
              key={index}
              className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-secondary-100 text-secondary-700"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>

      {/* External Links */}
      <div className="border-t border-border-light pt-6">
        <h3 className="text-sm font-medium text-text-primary mb-3">External Profiles</h3>
        <div className="space-y-2">
          <a 
            href={candidate.githubProfile}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-2 text-sm text-text-secondary hover:text-primary-600 transition-smooth"
          >
            <Icon name="Github" size={16} />
            <span>GitHub Profile</span>
            <Icon name="ExternalLink" size={12} />
          </a>
          <a 
            href={candidate.linkedinProfile}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-2 text-sm text-text-secondary hover:text-primary-600 transition-smooth"
          >
            <Icon name="Linkedin" size={16} />
            <span>LinkedIn Profile</span>
            <Icon name="ExternalLink" size={12} />
          </a>
        </div>
      </div>
    </div>
  );
};

export default CandidateCard;