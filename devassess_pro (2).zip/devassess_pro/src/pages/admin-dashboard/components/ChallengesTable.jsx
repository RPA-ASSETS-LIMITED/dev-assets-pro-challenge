import React, { useState, useMemo } from 'react';
import Icon from 'components/AppIcon';

const ChallengesTable = ({ challenges, searchTerm, sortConfig, setSortConfig }) => {
  const [selectedChallenges, setSelectedChallenges] = useState([]);
  const [bulkActionOpen, setBulkActionOpen] = useState(false);

  const getDifficultyColor = (difficulty) => {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return 'bg-success-100 text-success-700';
      case 'intermediate':
        return 'bg-warning-100 text-warning-700';
      case 'advanced':
        return 'bg-accent-100 text-accent-700';
      case 'expert':
        return 'bg-error-100 text-error-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getStatusColor = (status) => {
    return status === 'active' ?'bg-success-100 text-success-700' :'bg-secondary-100 text-secondary-700';
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedChallenges(filteredAndSortedChallenges.map(c => c.id));
    } else {
      setSelectedChallenges([]);
    }
  };

  const handleSelectChallenge = (challengeId, checked) => {
    if (checked) {
      setSelectedChallenges([...selectedChallenges, challengeId]);
    } else {
      setSelectedChallenges(selectedChallenges.filter(id => id !== challengeId));
    }
  };

  const handleBulkAction = (action) => {
    console.log(`Bulk action: ${action} on challenges:`, selectedChallenges);
    setBulkActionOpen(false);
    setSelectedChallenges([]);
  };

  const filteredAndSortedChallenges = useMemo(() => {
    let filtered = challenges.filter(challenge =>
      challenge.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      challenge.difficulty.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (sortConfig.key) {
      filtered.sort((a, b) => {
        let aValue = a[sortConfig.key];
        let bValue = b[sortConfig.key];

        if (sortConfig.key === 'createdAt') {
          aValue = aValue.getTime();
          bValue = bValue.getTime();
        }

        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    return filtered;
  }, [challenges, searchTerm, sortConfig]);

  const SortIcon = ({ column }) => {
    if (sortConfig.key !== column) {
      return <Icon name="ArrowUpDown" size={16} className="text-text-muted" />;
    }
    return (
      <Icon 
        name={sortConfig.direction === 'asc' ? 'ArrowUp' : 'ArrowDown'} 
        size={16} 
        className="text-primary" 
      />
    );
  };

  return (
    <div className="overflow-hidden">
      {/* Bulk Actions */}
      {selectedChallenges.length > 0 && (
        <div className="px-6 py-3 bg-primary-50 border-b border-border-light">
          <div className="flex items-center justify-between">
            <span className="text-sm text-primary-700">
              {selectedChallenges.length} challenge{selectedChallenges.length > 1 ? 's' : ''} selected
            </span>
            
            <div className="relative">
              <button
                onClick={() => setBulkActionOpen(!bulkActionOpen)}
                className="inline-flex items-center space-x-2 bg-primary text-white px-3 py-1.5 rounded text-sm hover:bg-primary-700 transition-smooth"
              >
                <span>Bulk Actions</span>
                <Icon name="ChevronDown" size={16} />
              </button>
              
              {bulkActionOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-surface rounded-lg shadow-modal border border-border z-10">
                  <div className="py-2">
                    <button
                      onClick={() => handleBulkAction('archive')}
                      className="w-full text-left px-4 py-2 text-sm text-text-secondary hover:bg-secondary-50 hover:text-text-primary transition-smooth"
                    >
                      Archive Selected
                    </button>
                    <button
                      onClick={() => handleBulkAction('duplicate')}
                      className="w-full text-left px-4 py-2 text-sm text-text-secondary hover:bg-secondary-50 hover:text-text-primary transition-smooth"
                    >
                      Duplicate Selected
                    </button>
                    <button
                      onClick={() => handleBulkAction('delete')}
                      className="w-full text-left px-4 py-2 text-sm text-error hover:bg-error-50 hover:text-error-600 transition-smooth"
                    >
                      Delete Selected
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-secondary-50 border-b border-border-light">
            <tr>
              <th className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedChallenges.length === filteredAndSortedChallenges.length && filteredAndSortedChallenges.length > 0}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="rounded border-border focus:ring-primary-500 focus:border-primary-500"
                />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => handleSort('title')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Title</span>
                  <SortIcon column="title" />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => handleSort('difficulty')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Difficulty</span>
                  <SortIcon column="difficulty" />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => handleSort('createdAt')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Created</span>
                  <SortIcon column="createdAt" />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => handleSort('assignedCandidates')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Assigned</span>
                  <SortIcon column="assignedCandidates" />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => handleSort('completionRate')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Completion</span>
                  <SortIcon column="completionRate" />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-text-secondary uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-surface divide-y divide-border-light">
            {filteredAndSortedChallenges.map((challenge) => (
              <tr key={challenge.id} className="hover:bg-secondary-50 transition-smooth">
                <td className="px-6 py-4">
                  <input
                    type="checkbox"
                    checked={selectedChallenges.includes(challenge.id)}
                    onChange={(e) => handleSelectChallenge(challenge.id, e.target.checked)}
                    className="rounded border-border focus:ring-primary-500 focus:border-primary-500"
                  />
                </td>
                <td className="px-6 py-4">
                  <div>
                    <div className="text-sm font-medium text-text-primary">{challenge.title}</div>
                    <div className="text-sm text-text-secondary line-clamp-1">{challenge.description}</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getDifficultyColor(challenge.difficulty)}`}>
                    {challenge.difficulty}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-text-secondary">
                  {formatDate(challenge.createdAt)}
                </td>
                <td className="px-6 py-4 text-sm text-text-primary">
                  {challenge.assignedCandidates}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <div className="flex-1 bg-secondary-200 rounded-full h-2 mr-2">
                      <div
                        className="bg-success h-2 rounded-full"
                        style={{ width: `${challenge.completionRate}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-text-primary">{challenge.completionRate}%</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(challenge.status)}`}>
                    {challenge.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end space-x-2">
                    <button
                      onClick={() => console.log('Edit challenge:', challenge.id)}
                      className="p-1 text-text-muted hover:text-accent transition-smooth"
                      title="Edit"
                    >
                      <Icon name="Edit" size={16} />
                    </button>
                    <button
                      onClick={() => console.log('Duplicate challenge:', challenge.id)}
                      className="p-1 text-text-muted hover:text-primary transition-smooth"
                      title="Duplicate"
                    >
                      <Icon name="Copy" size={16} />
                    </button>
                    <button
                      onClick={() => console.log('View submissions:', challenge.id)}
                      className="p-1 text-text-muted hover:text-success transition-smooth"
                      title="View Submissions"
                    >
                      <Icon name="Eye" size={16} />
                    </button>
                    <button
                      onClick={() => console.log('Archive challenge:', challenge.id)}
                      className="p-1 text-text-muted hover:text-warning transition-smooth"
                      title="Archive"
                    >
                      <Icon name="Archive" size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="lg:hidden divide-y divide-border-light">
        {filteredAndSortedChallenges.map((challenge) => (
          <div key={challenge.id} className="p-6">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={selectedChallenges.includes(challenge.id)}
                  onChange={(e) => handleSelectChallenge(challenge.id, e.target.checked)}
                  className="rounded border-border focus:ring-primary-500 focus:border-primary-500"
                />
                <div>
                  <h3 className="text-sm font-medium text-text-primary">{challenge.title}</h3>
                  <p className="text-xs text-text-secondary mt-1">{formatDate(challenge.createdAt)}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getDifficultyColor(challenge.difficulty)}`}>
                  {challenge.difficulty}
                </span>
                <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(challenge.status)}`}>
                  {challenge.status}
                </span>
              </div>
            </div>
            
            <p className="text-sm text-text-secondary mb-3 line-clamp-2">{challenge.description}</p>
            
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-text-secondary">
                <span className="font-medium text-text-primary">{challenge.assignedCandidates}</span> assigned
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-16 bg-secondary-200 rounded-full h-2">
                  <div
                    className="bg-success h-2 rounded-full"
                    style={{ width: `${challenge.completionRate}%` }}
                  ></div>
                </div>
                <span className="text-sm text-text-primary">{challenge.completionRate}%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => console.log('Edit challenge:', challenge.id)}
                className="flex items-center space-x-1 text-sm text-accent hover:text-accent-600 transition-smooth"
              >
                <Icon name="Edit" size={16} />
                <span>Edit</span>
              </button>
              <button
                onClick={() => console.log('View submissions:', challenge.id)}
                className="flex items-center space-x-1 text-sm text-success hover:text-success-600 transition-smooth"
              >
                <Icon name="Eye" size={16} />
                <span>View</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredAndSortedChallenges.length === 0 && (
        <div className="p-12 text-center">
          <Icon name="Search" size={48} className="text-text-muted mx-auto mb-4" />
          <h3 className="text-lg font-medium text-text-primary mb-2">No challenges found</h3>
          <p className="text-text-secondary">Try adjusting your search terms or create a new challenge.</p>
        </div>
      )}
    </div>
  );
};

export default ChallengesTable;