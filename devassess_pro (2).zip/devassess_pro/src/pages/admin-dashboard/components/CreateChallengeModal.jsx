import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const CreateChallengeModal = ({ isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    difficulty: 'Intermediate',
    requirements: '',
    timeLimit: '7',
    tags: ''
  });

  const [errors, setErrors] = useState({});

  const difficulties = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    if (!formData.requirements.trim()) {
      newErrors.requirements = 'Requirements are required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSave({
        ...formData,
        id: Date.now(),
        createdAt: new Date(),
        assignedCandidates: 0,
        completionRate: 0,
        status: 'active'
      });
      
      // Reset form
      setFormData({
        title: '',
        description: '',
        difficulty: 'Intermediate',
        requirements: '',
        timeLimit: '7',
        tags: ''
      });
      setErrors({});
    }
  };

  const handleClose = () => {
    setFormData({
      title: '',
      description: '',
      difficulty: 'Intermediate',
      requirements: '',
      timeLimit: '7',
      tags: ''
    });
    setErrors({});
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-surface rounded-lg shadow-modal w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border-light">
          <h2 className="text-xl font-semibold text-text-primary">Create New Challenge</h2>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-secondary-50 rounded-lg transition-smooth min-h-touch min-w-touch"
          >
            <Icon name="X" size={20} className="text-text-muted" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="p-6 space-y-6">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Challenge Title *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth ${
                  errors.title ? 'border-error' : 'border-border'
                }`}
                placeholder="Enter challenge title"
              />
              {errors.title && (
                <p className="mt-1 text-sm text-error">{errors.title}</p>
              )}
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Description *
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth resize-none ${
                  errors.description ? 'border-error' : 'border-border'
                }`}
                placeholder="Describe the challenge objectives and context"
              />
              {errors.description && (
                <p className="mt-1 text-sm text-error">{errors.description}</p>
              )}
            </div>

            {/* Difficulty and Time Limit */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Difficulty Level
                </label>
                <select
                  value={formData.difficulty}
                  onChange={(e) => handleInputChange('difficulty', e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                >
                  {difficulties.map((difficulty) => (
                    <option key={difficulty} value={difficulty}>
                      {difficulty}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Time Limit (days)
                </label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={formData.timeLimit}
                  onChange={(e) => handleInputChange('timeLimit', e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                />
              </div>
            </div>

            {/* Requirements */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Technical Requirements *
              </label>
              <textarea
                value={formData.requirements}
                onChange={(e) => handleInputChange('requirements', e.target.value)}
                rows={6}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth resize-none ${
                  errors.requirements ? 'border-error' : 'border-border'
                }`}
                placeholder="List specific technical requirements, technologies to use, deliverables, etc."
              />
              {errors.requirements && (
                <p className="mt-1 text-sm text-error">{errors.requirements}</p>
              )}
            </div>

            {/* Tags */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Tags (comma-separated)
              </label>
              <input
                type="text"
                value={formData.tags}
                onChange={(e) => handleInputChange('tags', e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth"
                placeholder="React, JavaScript, API, Frontend"
              />
              <p className="mt-1 text-sm text-text-muted">
                Add relevant tags to help categorize this challenge
              </p>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end space-x-4 p-6 border-t border-border-light bg-secondary-50">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2 text-text-secondary hover:text-text-primary transition-smooth min-h-touch"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center space-x-2 bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary-700 transition-smooth min-h-touch"
            >
              <Icon name="Plus" size={16} />
              <span>Create Challenge</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateChallengeModal;