import React from 'react';
import Icon from 'components/AppIcon';

const RecentActivity = () => {
  const activities = [
    {
      id: 1,
      type: 'submission',
      user: 'Sarah Johnson',
      action: 'submitted solution for',
      target: 'React Component Library',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      icon: 'FileText',
      color: 'success'
    },
    {
      id: 2,
      type: 'challenge',
      user: 'Admin',
      action: 'created new challenge',
      target: 'Node.js Microservices',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      icon: 'Plus',
      color: 'primary'
    },
    {
      id: 3,
      type: 'registration',
      user: 'Mike Chen',
      action: 'registered as candidate',
      target: '',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      icon: 'UserPlus',
      color: 'accent'
    },
    {
      id: 4,
      type: 'completion',
      user: 'Emma Davis',
      action: 'completed challenge',
      target: 'JavaScript Algorithms',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      icon: 'CheckCircle',
      color: 'success'
    },
    {
      id: 5,
      type: 'assignment',
      user: 'Recruiter',
      action: 'assigned challenge to',
      target: '3 candidates',
      timestamp: new Date(Date.now() - 60 * 60 * 1000),
      icon: 'Users',
      color: 'warning'
    }
  ];

  const getIconColor = (color) => {
    switch (color) {
      case 'primary':
        return 'text-primary';
      case 'success':
        return 'text-success';
      case 'accent':
        return 'text-accent';
      case 'warning':
        return 'text-warning';
      default:
        return 'text-text-muted';
    }
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    return `${hours}h ago`;
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border">
      <div className="p-6 border-b border-border-light">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-text-primary">Recent Activity</h3>
          <button className="text-sm text-accent hover:text-accent-600 transition-smooth">
            View All
          </button>
        </div>
      </div>
      
      <div className="p-6">
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-8 h-8 rounded-full bg-secondary-100 flex items-center justify-center ${getIconColor(activity.color)}`}>
                <Icon name={activity.icon} size={16} />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="text-sm text-text-primary">
                  <span className="font-medium">{activity.user}</span>
                  <span className="text-text-secondary"> {activity.action} </span>
                  {activity.target && (
                    <span className="font-medium">{activity.target}</span>
                  )}
                </div>
                <div className="text-xs text-text-muted mt-1">
                  {formatTimestamp(activity.timestamp)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;