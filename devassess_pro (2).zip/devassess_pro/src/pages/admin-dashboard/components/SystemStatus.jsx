import React from 'react';
import Icon from 'components/AppIcon';

const SystemStatus = () => {
  const systemMetrics = [
    {
      id: 1,
      name: 'API Response Time',
      value: '142ms',
      status: 'good',
      icon: 'Zap'
    },
    {
      id: 2,
      name: 'Database Health',
      value: '99.9%',
      status: 'good',
      icon: 'Database'
    },
    {
      id: 3,
      name: 'Active Sessions',
      value: '1,247',
      status: 'good',
      icon: 'Users'
    },
    {
      id: 4,
      name: 'Storage Usage',
      value: '67%',
      status: 'warning',
      icon: 'HardDrive'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'good':
        return 'text-success';
      case 'warning':
        return 'text-warning';
      case 'error':
        return 'text-error';
      default:
        return 'text-text-muted';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'good':
        return 'CheckCircle';
      case 'warning':
        return 'AlertTriangle';
      case 'error':
        return 'AlertCircle';
      default:
        return 'Circle';
    }
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border">
      <div className="p-6 border-b border-border-light">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-text-primary">System Status</h3>
          <div className="flex items-center space-x-2">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span className="text-sm text-success font-medium">All Systems Operational</span>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="space-y-4">
          {systemMetrics.map((metric) => (
            <div key={metric.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Icon name={metric.icon} size={16} className="text-text-muted" />
                <span className="text-sm text-text-secondary">{metric.name}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-text-primary">{metric.value}</span>
                <Icon 
                  name={getStatusIcon(metric.status)} 
                  size={16} 
                  className={getStatusColor(metric.status)} 
                />
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 pt-4 border-t border-border-light">
          <button className="w-full text-center text-sm text-accent hover:text-accent-600 transition-smooth py-2">
            View Detailed Status
          </button>
        </div>
      </div>
    </div>
  );
};

export default SystemStatus;