import React from 'react';
import Icon from 'components/AppIcon';

const MetricsCard = ({ title, value, change, changeType, icon, color }) => {
  const getColorClasses = (color) => {
    switch (color) {
      case 'primary':
        return 'bg-primary-100 text-primary-700';
      case 'success':
        return 'bg-success-100 text-success-700';
      case 'accent':
        return 'bg-accent-100 text-accent-700';
      case 'warning':
        return 'bg-warning-100 text-warning-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getChangeColor = (changeType) => {
    return changeType === 'increase' ? 'text-success' : 'text-error';
  };

  const getChangeIcon = (changeType) => {
    return changeType === 'increase' ? 'TrendingUp' : 'TrendingDown';
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border p-6 hover:shadow-modal transition-smooth">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-text-secondary mb-1">{title}</p>
          <p className="text-3xl font-bold text-text-primary mb-2">{value}</p>
          
          <div className="flex items-center space-x-1">
            <Icon 
              name={getChangeIcon(changeType)} 
              size={16} 
              className={getChangeColor(changeType)} 
            />
            <span className={`text-sm font-medium ${getChangeColor(changeType)}`}>
              {change}
            </span>
            <span className="text-sm text-text-muted">vs last month</span>
          </div>
        </div>
        
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(color)}`}>
          <Icon name={icon} size={24} />
        </div>
      </div>
    </div>
  );
};

export default MetricsCard;