import React from 'react';
import Icon from 'components/AppIcon';

const QuickActions = ({ onCreateChallenge }) => {
  const actions = [
    {
      id: 1,
      title: 'Create Challenge',
      description: 'Add a new coding challenge',
      icon: 'Plus',
      color: 'primary',
      action: onCreateChallenge
    },
    {
      id: 2,
      title: 'Invite Candidates',
      description: 'Send invitations to new candidates',
      icon: 'UserPlus',
      color: 'success',
      action: () => console.log('Invite candidates')
    },
    {
      id: 3,
      title: 'View Reports',
      description: 'Check platform analytics',
      icon: 'BarChart3',
      color: 'accent',
      action: () => console.log('View reports')
    },
    {
      id: 4,
      title: 'Manage Users',
      description: 'Admin user management',
      icon: 'Settings',
      color: 'warning',
      action: () => console.log('Manage users')
    }
  ];

  const getColorClasses = (color) => {
    switch (color) {
      case 'primary':
        return 'bg-primary hover:bg-primary-700 text-white';
      case 'success':
        return 'bg-success hover:bg-success-600 text-white';
      case 'accent':
        return 'bg-accent hover:bg-accent-600 text-white';
      case 'warning':
        return 'bg-warning hover:bg-warning-600 text-white';
      default:
        return 'bg-secondary hover:bg-secondary-600 text-white';
    }
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border">
      <div className="p-6 border-b border-border-light">
        <h3 className="text-lg font-semibold text-text-primary">Quick Actions</h3>
      </div>
      
      <div className="p-6">
        <div className="space-y-3">
          {actions.map((action) => (
            <button
              key={action.id}
              onClick={action.action}
              className={`w-full p-4 rounded-lg transition-smooth text-left ${getColorClasses(action.color)} min-h-touch`}
            >
              <div className="flex items-center space-x-3">
                <Icon name={action.icon} size={20} />
                <div>
                  <div className="font-medium">{action.title}</div>
                  <div className="text-sm opacity-90">{action.description}</div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuickActions;