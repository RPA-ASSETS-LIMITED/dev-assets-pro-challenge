import React, { useState } from 'react';
import RoleBasedNavigation from 'components/ui/RoleBasedNavigation';
import BreadcrumbNavigation from 'components/ui/BreadcrumbNavigation';
import NotificationIndicator from 'components/ui/NotificationIndicator';
import UserProfileDropdown from 'components/ui/UserProfileDropdown';
import Icon from 'components/AppIcon';
import MetricsCard from './components/MetricsCard';
import ChallengesTable from './components/ChallengesTable';
import RecentActivity from './components/RecentActivity';
import QuickActions from './components/QuickActions';
import SystemStatus from './components/SystemStatus';
import CreateChallengeModal from './components/CreateChallengeModal';

const AdminDashboard = () => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: 'createdAt', direction: 'desc' });

  // Mock data for metrics
  const metricsData = [
    {
      id: 1,
      title: 'Total Challenges',
      value: '24',
      change: '+3',
      changeType: 'increase',
      icon: 'Code',
      color: 'primary'
    },
    {
      id: 2,
      title: 'Active Candidates',
      value: '156',
      change: '+12',
      changeType: 'increase',
      icon: 'Users',
      color: 'success'
    },
    {
      id: 3,
      title: 'Completion Rate',
      value: '78%',
      change: '+5%',
      changeType: 'increase',
      icon: 'TrendingUp',
      color: 'accent'
    },
    {
      id: 4,
      title: 'Recent Submissions',
      value: '42',
      change: '-2',
      changeType: 'decrease',
      icon: 'FileText',
      color: 'warning'
    }
  ];

  // Mock data for challenges
  const challengesData = [
    {
      id: 1,
      title: 'React Component Library',
      difficulty: 'Advanced',
      createdAt: new Date('2024-01-15'),
      assignedCandidates: 12,
      completionRate: 85,
      status: 'active',
      description: `Build a comprehensive React component library with TypeScript support, including common UI components like buttons, forms, modals, and data tables. The library should follow modern React patterns and include proper documentation.`
    },
    {
      id: 2,
      title: 'Full Stack E-commerce API',
      difficulty: 'Expert',
      createdAt: new Date('2024-01-10'),
      assignedCandidates: 8,
      completionRate: 62,
      status: 'active',
      description: `Create a complete e-commerce backend API with user authentication, product management, shopping cart functionality, and payment integration. Include comprehensive testing and API documentation.`
    },
    {
      id: 3,
      title: 'JavaScript Algorithm Challenge',
      difficulty: 'Intermediate',
      createdAt: new Date('2024-01-08'),
      assignedCandidates: 25,
      completionRate: 92,
      status: 'active',
      description: `Solve a series of algorithmic problems focusing on data structures, sorting algorithms, and optimization techniques. Solutions should be efficient and well-documented.`
    },
    {
      id: 4,
      title: 'CSS Grid Layout System',
      difficulty: 'Beginner',
      createdAt: new Date('2024-01-05'),
      assignedCandidates: 18,
      completionRate: 94,
      status: 'archived',
      description: `Design and implement a responsive grid layout system using CSS Grid and Flexbox. The system should support various breakpoints and component arrangements.`
    },
    {
      id: 5,
      title: 'Node.js Microservices',
      difficulty: 'Expert',
      createdAt: new Date('2024-01-03'),
      assignedCandidates: 6,
      completionRate: 50,
      status: 'active',
      description: `Build a microservices architecture using Node.js, including service discovery, API gateway, and inter-service communication. Implement proper logging and monitoring.`
    }
  ];

  const handleCreateChallenge = () => {
    setIsCreateModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsCreateModalOpen(false);
  };

  const handleSaveChallenge = (challengeData) => {
    console.log('Saving challenge:', challengeData);
    setIsCreateModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <RoleBasedNavigation userRole="admin" currentPath="/admin-dashboard" />
      
      {/* Breadcrumb */}
      <BreadcrumbNavigation currentPath="/admin-dashboard" userRole="admin" />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header Section */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-text-primary mb-2">Admin Dashboard</h1>
            <p className="text-text-secondary">Manage coding challenges and monitor platform performance</p>
          </div>
          
          <div className="flex items-center space-x-4 mt-4 lg:mt-0">
            <NotificationIndicator userRole="admin" />
            <UserProfileDropdown 
              userRole="admin" 
              userName="Admin User" 
              userEmail="admin@devassess.com" 
            />
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
          {metricsData.map((metric) => (
            <MetricsCard key={metric.id} {...metric} />
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          {/* Primary Content Area */}
          <div className="xl:col-span-8">
            {/* Search and Actions */}
            <div className="bg-surface rounded-lg shadow-card border border-border mb-6">
              <div className="p-6 border-b border-border-light">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                  <h2 className="text-xl font-semibold text-text-primary">Coding Challenges</h2>
                  
                  <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                    <div className="relative">
                      <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted" />
                      <input
                        type="text"
                        placeholder="Search challenges..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth min-w-[200px]"
                      />
                    </div>
                    
                    <button
                      onClick={handleCreateChallenge}
                      className="inline-flex items-center space-x-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-smooth min-h-touch"
                    >
                      <Icon name="Plus" size={20} />
                      <span>Create Challenge</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Challenges Table */}
              <ChallengesTable 
                challenges={challengesData}
                searchTerm={searchTerm}
                sortConfig={sortConfig}
                setSortConfig={setSortConfig}
              />
            </div>
          </div>

          {/* Sidebar */}
          <div className="xl:col-span-4 space-y-6">
            {/* Quick Actions */}
            <QuickActions onCreateChallenge={handleCreateChallenge} />
            
            {/* Recent Activity */}
            <RecentActivity />
            
            {/* System Status */}
            <SystemStatus />
          </div>
        </div>
      </div>

      {/* Create Challenge Modal */}
      {isCreateModalOpen && (
        <CreateChallengeModal
          isOpen={isCreateModalOpen}
          onClose={handleCloseModal}
          onSave={handleSaveChallenge}
        />
      )}
    </div>
  );
};

export default AdminDashboard;