import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const InviteCandidateModal = ({ isOpen, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    email: '',
    challengeId: '',
    customMessage: '',
    deadline: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const availableChallenges = [
    { id: 'react-frontend', name: 'React Frontend Assessment', difficulty: 'Medium', duration: '4 hours' },
    { id: 'fullstack-dev', name: 'Full Stack Developer Challenge', difficulty: 'Hard', duration: '6 hours' },
    { id: 'nodejs-backend', name: 'Node.js Backend Assessment', difficulty: 'Medium', duration: '3 hours' },
    { id: 'python-data', name: 'Python Data Analysis', difficulty: 'Easy', duration: '2 hours' },
    { id: 'react-native', name: 'React Native Mobile App', difficulty: 'Hard', duration: '5 hours' }
  ];

  const defaultMessage = `Hello,

You have been invited to complete a technical assessment as part of our hiring process. This assessment will help us evaluate your technical skills and problem-solving abilities.

Please complete the challenge within the specified timeframe. If you have any questions, feel free to reach out to us.

Best regards,
The Recruitment Team`;

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.challengeId) {
      newErrors.challengeId = 'Please select a challenge';
    }

    if (!formData.deadline) {
      newErrors.deadline = 'Please set a deadline';
    } else {
      const selectedDate = new Date(formData.deadline);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate <= today) {
        newErrors.deadline = 'Deadline must be in the future';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      const selectedChallenge = availableChallenges.find(c => c.id === formData.challengeId);
      const inviteData = {
        ...formData,
        challengeName: selectedChallenge?.name,
        customMessage: formData.customMessage || defaultMessage
      };
      
      await onSubmit(inviteData);
      
      // Reset form
      setFormData({
        email: '',
        challengeId: '',
        customMessage: '',
        deadline: ''
      });
      setErrors({});
    } catch (error) {
      console.error('Error sending invitation:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setFormData({
        email: '',
        challengeId: '',
        customMessage: '',
        deadline: ''
      });
      setErrors({});
      onClose();
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'text-success bg-success-50';
      case 'medium':
        return 'text-warning bg-warning-50';
      case 'hard':
        return 'text-error bg-error-50';
      default:
        return 'text-secondary bg-secondary-50';
    }
  };

  // Get minimum date (tomorrow)
  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-1020">
      <div className="bg-surface rounded-lg shadow-modal max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border-light">
          <div>
            <h2 className="text-xl font-semibold text-text-primary">Invite Candidate</h2>
            <p className="text-sm text-text-secondary mt-1">Send assessment invitation to a new candidate</p>
          </div>
          <button
            onClick={handleClose}
            disabled={isSubmitting}
            className="p-2 hover:bg-secondary-50 rounded-lg transition-smooth disabled:opacity-50"
          >
            <Icon name="X" size={20} className="text-text-secondary" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Email Input */}
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Candidate Email *
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="candidate@example.com"
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth ${
                errors.email ? 'border-error' : 'border-border'
              }`}
              disabled={isSubmitting}
            />
            {errors.email && (
              <p className="text-error text-sm mt-1 flex items-center">
                <Icon name="AlertCircle" size={14} className="mr-1" />
                {errors.email}
              </p>
            )}
          </div>

          {/* Challenge Selection */}
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Select Challenge *
            </label>
            <select
              value={formData.challengeId}
              onChange={(e) => handleInputChange('challengeId', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth ${
                errors.challengeId ? 'border-error' : 'border-border'
              }`}
              disabled={isSubmitting}
            >
              <option value="">Choose a challenge...</option>
              {availableChallenges.map((challenge) => (
                <option key={challenge.id} value={challenge.id}>
                  {challenge.name} ({challenge.difficulty} - {challenge.duration})
                </option>
              ))}
            </select>
            {errors.challengeId && (
              <p className="text-error text-sm mt-1 flex items-center">
                <Icon name="AlertCircle" size={14} className="mr-1" />
                {errors.challengeId}
              </p>
            )}
            
            {/* Challenge Details */}
            {formData.challengeId && (
              <div className="mt-3 p-3 bg-secondary-50 rounded-lg">
                {(() => {
                  const selectedChallenge = availableChallenges.find(c => c.id === formData.challengeId);
                  return (
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium text-text-primary">{selectedChallenge?.name}</div>
                        <div className="text-xs text-text-secondary">Duration: {selectedChallenge?.duration}</div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(selectedChallenge?.difficulty)}`}>
                        {selectedChallenge?.difficulty}
                      </span>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Deadline */}
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Deadline *
            </label>
            <input
              type="date"
              value={formData.deadline}
              onChange={(e) => handleInputChange('deadline', e.target.value)}
              min={getMinDate()}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth ${
                errors.deadline ? 'border-error' : 'border-border'
              }`}
              disabled={isSubmitting}
            />
            {errors.deadline && (
              <p className="text-error text-sm mt-1 flex items-center">
                <Icon name="AlertCircle" size={14} className="mr-1" />
                {errors.deadline}
              </p>
            )}
          </div>

          {/* Custom Message */}
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Custom Message (Optional)
            </label>
            <textarea
              value={formData.customMessage}
              onChange={(e) => handleInputChange('customMessage', e.target.value)}
              placeholder={defaultMessage}
              rows={6}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth resize-vertical"
              disabled={isSubmitting}
            />
            <p className="text-xs text-text-muted mt-1">
              Leave empty to use the default invitation message
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-border-light">
            <button
              type="button"
              onClick={handleClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-text-secondary hover:text-text-primary hover:bg-secondary-50 rounded-lg transition-smooth disabled:opacity-50 min-h-touch"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-smooth disabled:opacity-50 disabled:cursor-not-allowed min-h-touch flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <Icon name="Loader2" size={16} className="animate-spin" />
                  <span>Sending...</span>
                </>
              ) : (
                <>
                  <Icon name="Send" size={16} />
                  <span>Send Invitation</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default InviteCandidateModal;