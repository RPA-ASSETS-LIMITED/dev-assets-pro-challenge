import React from 'react';
import Icon from 'components/AppIcon';

const SummaryCards = ({ metrics }) => {
  const cards = [
    {
      title: 'Active Candidates',
      value: metrics.activeCandidates,
      icon: 'Users',
      color: 'text-primary',
      bgColor: 'bg-primary-50',
      change: '+12%',
      changeType: 'positive'
    },
    {
      title: 'Pending Invitations',
      value: metrics.pendingInvitations,
      icon: 'Mail',
      color: 'text-warning',
      bgColor: 'bg-warning-50',
      change: '+3',
      changeType: 'neutral'
    },
    {
      title: 'Completed Assessments',
      value: metrics.completedAssessments,
      icon: 'CheckCircle',
      color: 'text-success',
      bgColor: 'bg-success-50',
      change: '+8%',
      changeType: 'positive'
    },
    {
      title: 'Avg. Completion Time',
      value: metrics.averageCompletionTime,
      icon: 'Clock',
      color: 'text-accent',
      bgColor: 'bg-accent-50',
      change: '-0.3 days',
      changeType: 'positive'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <div key={index} className="bg-surface rounded-lg border border-border p-6 hover:shadow-card transition-smooth">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-sm font-medium text-text-secondary mb-1">{card.title}</p>
              <p className="text-2xl font-semibold text-text-primary">{card.value}</p>
              <div className="flex items-center mt-2">
                <span className={`text-xs font-medium ${
                  card.changeType === 'positive' ? 'text-success' : 
                  card.changeType === 'negative' ? 'text-error' : 'text-text-secondary'
                }`}>
                  {card.change}
                </span>
                <span className="text-xs text-text-muted ml-1">vs last month</span>
              </div>
            </div>
            <div className={`w-12 h-12 ${card.bgColor} rounded-lg flex items-center justify-center`}>
              <Icon name={card.icon} size={24} className={card.color} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SummaryCards;