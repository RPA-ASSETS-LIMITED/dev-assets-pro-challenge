import React from 'react';
import Icon from 'components/AppIcon';

const QuickActionsPanel = ({ onInviteCandidate }) => {
  const quickActions = [
    {
      title: 'Invite Candidate',
      description: 'Send assessment invitation to new candidate',
      icon: 'UserPlus',
      color: 'text-primary',
      bgColor: 'bg-primary-50',
      action: onInviteCandidate
    },
    {
      title: 'Bulk Reminder',
      description: 'Send reminders to pending candidates',
      icon: 'Bell',
      color: 'text-warning',
      bgColor: 'bg-warning-50',
      action: () => console.log('Bulk reminder clicked')
    },
    {
      title: 'Export Data',
      description: 'Download candidate progress report',
      icon: 'Download',
      color: 'text-accent',
      bgColor: 'bg-accent-50',
      action: () => console.log('Export data clicked')
    }
  ];

  const challengeShortcuts = [
    { name: 'React Frontend', count: 8, difficulty: 'Medium' },
    { name: 'Full Stack', count: 5, difficulty: 'Hard' },
    { name: 'Node.js Backend', count: 12, difficulty: 'Medium' },
    { name: 'Python Data', count: 3, difficulty: 'Easy' }
  ];

  const getDifficultyColor = (difficulty) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'text-success bg-success-50';
      case 'medium':
        return 'text-warning bg-warning-50';
      case 'hard':
        return 'text-error bg-error-50';
      default:
        return 'text-secondary bg-secondary-50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="bg-surface rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Quick Actions</h3>
        <div className="space-y-3">
          {quickActions.map((action, index) => (
            <button
              key={index}
              onClick={action.action}
              className="w-full text-left p-3 rounded-lg border border-border hover:border-primary-300 hover:bg-primary-50 transition-smooth group"
            >
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 ${action.bgColor} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon name={action.icon} size={20} className={action.color} />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-text-primary">{action.title}</div>
                  <div className="text-xs text-text-secondary">{action.description}</div>
                </div>
                <Icon name="ChevronRight" size={16} className="text-text-muted group-hover:text-primary transition-smooth" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Challenge Shortcuts */}
      <div className="bg-surface rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Challenge Shortcuts</h3>
          <button className="text-sm text-accent hover:text-accent-600 transition-smooth">
            View All
          </button>
        </div>
        <div className="space-y-3">
          {challengeShortcuts.map((challenge, index) => (
            <div key={index} className="flex items-center justify-between p-3 rounded-lg border border-border-light hover:bg-secondary-50 transition-smooth">
              <div className="flex-1">
                <div className="text-sm font-medium text-text-primary">{challenge.name}</div>
                <div className="text-xs text-text-secondary">{challenge.count} active candidates</div>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(challenge.difficulty)}`}>
                {challenge.difficulty}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="bg-surface rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">This Week</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="UserCheck" size={16} className="text-success" />
              <span className="text-sm text-text-secondary">Completed</span>
            </div>
            <span className="text-sm font-medium text-text-primary">12</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={16} className="text-warning" />
              <span className="text-sm text-text-secondary">In Progress</span>
            </div>
            <span className="text-sm font-medium text-text-primary">8</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Mail" size={16} className="text-accent" />
              <span className="text-sm text-text-secondary">Invited</span>
            </div>
            <span className="text-sm font-medium text-text-primary">15</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickActionsPanel;