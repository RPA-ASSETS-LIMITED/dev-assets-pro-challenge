import React from 'react';
import Icon from 'components/AppIcon';

const RecentActivity = () => {
  const activities = [
    {
      id: 1,
      type: 'submission',
      user: 'Sarah Johnson',
      action: 'submitted React Frontend Assessment',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      icon: 'Upload',
      color: 'text-success'
    },
    {
      id: 2,
      type: 'invitation',
      user: 'Michael Chen',
      action: 'was invited to Full Stack Challenge',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      icon: 'Mail',
      color: 'text-accent'
    },
    {
      id: 3,
      type: 'started',
      user: 'Emily Rodriguez',
      action: 'started Node.js Backend Assessment',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      icon: 'Play',
      color: 'text-warning'
    },
    {
      id: 4,
      type: 'evaluation',
      user: 'David Kim',
      action: 'assessment was evaluated and approved',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      icon: 'CheckCircle',
      color: 'text-success'
    },
    {
      id: 5,
      type: 'reminder',
      user: 'Lisa Thompson',
      action: 'was sent a reminder for Python Challenge',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      icon: 'Bell',
      color: 'text-warning'
    },
    {
      id: 6,
      type: 'registration',
      user: 'Alex Wilson',
      action: 'registered and was assigned React Assessment',
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
      icon: 'UserPlus',
      color: 'text-primary'
    }
  ];

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const getActivityBgColor = (type) => {
    switch (type) {
      case 'submission':
        return 'bg-success-50';
      case 'invitation':
        return 'bg-accent-50';
      case 'started':
        return 'bg-warning-50';
      case 'evaluation':
        return 'bg-success-50';
      case 'reminder':
        return 'bg-warning-50';
      case 'registration':
        return 'bg-primary-50';
      default:
        return 'bg-secondary-50';
    }
  };

  return (
    <div className="bg-surface rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-text-primary">Recent Activity</h3>
        <button className="text-sm text-accent hover:text-accent-600 transition-smooth">
          View All
        </button>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {activities.map((activity, index) => (
          <div key={activity.id} className="flex items-start space-x-3">
            <div className={`w-8 h-8 ${getActivityBgColor(activity.type)} rounded-full flex items-center justify-center flex-shrink-0`}>
              <Icon name={activity.icon} size={14} className={activity.color} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm text-text-primary">
                <span className="font-medium">{activity.user}</span>
                <span className="text-text-secondary ml-1">{activity.action}</span>
              </div>
              <div className="text-xs text-text-muted mt-1">
                {formatTimestamp(activity.timestamp)}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Activity Summary */}
      <div className="mt-6 pt-4 border-t border-border-light">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-lg font-semibold text-text-primary">24</div>
            <div className="text-xs text-text-secondary">Today's Activities</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-text-primary">156</div>
            <div className="text-xs text-text-secondary">This Week</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;