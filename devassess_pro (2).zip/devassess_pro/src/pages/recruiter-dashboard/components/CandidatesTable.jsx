import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const CandidatesTable = ({ 
  candidates, 
  selectedCandidates, 
  setSelectedCandidates, 
  sortConfig, 
  onSort 
}) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'invited':
        return 'bg-secondary-100 text-secondary-700';
      case 'in-progress':
        return 'bg-warning-100 text-warning-700';
      case 'submitted':
        return 'bg-accent-100 text-accent-700';
      case 'evaluated':
        return 'bg-success-100 text-success-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'invited':
        return 'Mail';
      case 'in-progress':
        return 'Clock';
      case 'submitted':
        return 'Upload';
      case 'evaluated':
        return 'CheckCircle';
      default:
        return 'Circle';
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedCandidates(candidates.map(c => c.id));
    } else {
      setSelectedCandidates([]);
    }
  };

  const handleSelectCandidate = (candidateId, checked) => {
    if (checked) {
      setSelectedCandidates([...selectedCandidates, candidateId]);
    } else {
      setSelectedCandidates(selectedCandidates.filter(id => id !== candidateId));
    }
  };

  const getSortIcon = (columnKey) => {
    if (sortConfig.key !== columnKey) {
      return 'ArrowUpDown';
    }
    return sortConfig.direction === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const handleCandidateAction = (action, candidateId) => {
    console.log(`${action} action for candidate:`, candidateId);
    // Handle different actions here
  };

  return (
    <div className="overflow-hidden">
      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="min-w-full divide-y divide-border-light">
          <thead className="bg-secondary-50">
            <tr>
              <th className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedCandidates.length === candidates.length && candidates.length > 0}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary-500"
                />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => onSort('name')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Candidate</span>
                  <Icon name={getSortIcon('name')} size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => onSort('assignedChallenge')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Challenge</span>
                  <Icon name={getSortIcon('assignedChallenge')} size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => onSort('status')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Status</span>
                  <Icon name={getSortIcon('status')} size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Progress
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                <button
                  onClick={() => onSort('submissionDate')}
                  className="flex items-center space-x-1 hover:text-text-primary transition-smooth"
                >
                  <span>Submission</span>
                  <Icon name={getSortIcon('submissionDate')} size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-text-secondary uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-surface divide-y divide-border-light">
            {candidates.map((candidate) => (
              <tr key={candidate.id} className="hover:bg-secondary-50 transition-smooth">
                <td className="px-6 py-4">
                  <input
                    type="checkbox"
                    checked={selectedCandidates.includes(candidate.id)}
                    onChange={(e) => handleSelectCandidate(candidate.id, e.target.checked)}
                    className="rounded border-border text-primary focus:ring-primary-500"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-secondary-200 flex-shrink-0">
                      <Image
                        src={candidate.avatar}
                        alt={candidate.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-text-primary">{candidate.name}</div>
                      <div className="text-sm text-text-secondary">{candidate.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-text-primary">{candidate.assignedChallenge}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(candidate.status)}`}>
                    <Icon name={getStatusIcon(candidate.status)} size={12} className="mr-1" />
                    {candidate.status.charAt(0).toUpperCase() + candidate.status.slice(1).replace('-', ' ')}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="w-full bg-secondary-200 rounded-full h-2 mr-2">
                      <div
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ width: `${candidate.progress}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-text-secondary min-w-[3rem]">{candidate.progress}%</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                  {formatDate(candidate.submissionDate)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex items-center justify-end space-x-2">
                    <button
                      onClick={() => handleCandidateAction('view', candidate.id)}
                      className="text-accent hover:text-accent-600 transition-smooth p-1 rounded"
                      title="View Profile"
                    >
                      <Icon name="Eye" size={16} />
                    </button>
                    <button
                      onClick={() => handleCandidateAction('remind', candidate.id)}
                      className="text-warning hover:text-warning-600 transition-smooth p-1 rounded"
                      title="Send Reminder"
                    >
                      <Icon name="Bell" size={16} />
                    </button>
                    <button
                      onClick={() => handleCandidateAction('reassign', candidate.id)}
                      className="text-secondary hover:text-secondary-600 transition-smooth p-1 rounded"
                      title="Reassign Challenge"
                    >
                      <Icon name="RefreshCw" size={16} />
                    </button>
                    {candidate.status === 'submitted' && (
                      <button
                        onClick={() => handleCandidateAction('evaluate', candidate.id)}
                        className="text-success hover:text-success-600 transition-smooth p-1 rounded"
                        title="Evaluate"
                      >
                        <Icon name="CheckCircle" size={16} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="lg:hidden space-y-4 p-4">
        {candidates.map((candidate) => (
          <div key={candidate.id} className="bg-surface border border-border rounded-lg p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={selectedCandidates.includes(candidate.id)}
                  onChange={(e) => handleSelectCandidate(candidate.id, e.target.checked)}
                  className="rounded border-border text-primary focus:ring-primary-500"
                />
                <div className="w-10 h-10 rounded-full overflow-hidden bg-secondary-200 flex-shrink-0">
                  <Image
                    src={candidate.avatar}
                    alt={candidate.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="text-sm font-medium text-text-primary">{candidate.name}</div>
                  <div className="text-xs text-text-secondary">{candidate.email}</div>
                </div>
              </div>
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(candidate.status)}`}>
                <Icon name={getStatusIcon(candidate.status)} size={10} className="mr-1" />
                {candidate.status.charAt(0).toUpperCase() + candidate.status.slice(1).replace('-', ' ')}
              </span>
            </div>
            
            <div className="space-y-2 mb-3">
              <div className="text-sm">
                <span className="text-text-secondary">Challenge:</span>
                <span className="text-text-primary ml-1">{candidate.assignedChallenge}</span>
              </div>
              <div className="text-sm">
                <span className="text-text-secondary">Submission:</span>
                <span className="text-text-primary ml-1">{formatDate(candidate.submissionDate)}</span>
              </div>
            </div>

            <div className="mb-3">
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-text-secondary">Progress</span>
                <span className="text-text-primary">{candidate.progress}%</span>
              </div>
              <div className="w-full bg-secondary-200 rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${candidate.progress}%` }}
                ></div>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-border-light">
              <button
                onClick={() => handleCandidateAction('view', candidate.id)}
                className="flex items-center space-x-1 text-accent hover:text-accent-600 transition-smooth px-2 py-1 rounded text-sm"
              >
                <Icon name="Eye" size={14} />
                <span>View</span>
              </button>
              <button
                onClick={() => handleCandidateAction('remind', candidate.id)}
                className="flex items-center space-x-1 text-warning hover:text-warning-600 transition-smooth px-2 py-1 rounded text-sm"
              >
                <Icon name="Bell" size={14} />
                <span>Remind</span>
              </button>
              {candidate.status === 'submitted' && (
                <button
                  onClick={() => handleCandidateAction('evaluate', candidate.id)}
                  className="flex items-center space-x-1 text-success hover:text-success-600 transition-smooth px-2 py-1 rounded text-sm"
                >
                  <Icon name="CheckCircle" size={14} />
                  <span>Evaluate</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {candidates.length === 0 && (
        <div className="text-center py-12">
          <Icon name="Users" size={48} className="text-text-muted mx-auto mb-4" />
          <h3 className="text-lg font-medium text-text-primary mb-2">No candidates found</h3>
          <p className="text-text-secondary">Try adjusting your search or filter criteria.</p>
        </div>
      )}
    </div>
  );
};

export default CandidatesTable;