import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import RoleBasedNavigation from 'components/ui/RoleBasedNavigation';
import BreadcrumbNavigation from 'components/ui/BreadcrumbNavigation';
import NotificationIndicator from 'components/ui/NotificationIndicator';
import UserProfileDropdown from 'components/ui/UserProfileDropdown';
import SummaryCards from './components/SummaryCards';
import CandidatesTable from './components/CandidatesTable';
import QuickActionsPanel from './components/QuickActionsPanel';
import RecentActivity from './components/RecentActivity';
import InviteCandidateModal from './components/InviteCandidateModal';

const RecruiterDashboard = () => {
  const [selectedTab, setSelectedTab] = useState('dashboard');
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedCandidates, setSelectedCandidates] = useState([]);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

  // Mock data for dashboard metrics
  const dashboardMetrics = {
    activeCandidates: 24,
    pendingInvitations: 8,
    completedAssessments: 156,
    averageCompletionTime: "4.2 days"
  };

  // Mock candidates data
  const candidatesData = [
    {
      id: 1,
      name: "Sarah Johnson",
      email: "sarah.johnson@email.com",
      assignedChallenge: "React Frontend Assessment",
      status: "in-progress",
      submissionDate: "2024-01-15",
      progress: 75,
      invitedDate: "2024-01-10",
      avatar: "https://randomuser.me/api/portraits/women/1.jpg"
    },
    {
      id: 2,
      name: "Michael Chen",
      email: "michael.chen@email.com",
      assignedChallenge: "Full Stack Developer Challenge",
      status: "submitted",
      submissionDate: "2024-01-14",
      progress: 100,
      invitedDate: "2024-01-08",
      avatar: "https://randomuser.me/api/portraits/men/2.jpg"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      email: "emily.rodriguez@email.com",
      assignedChallenge: "Node.js Backend Assessment",
      status: "invited",
      submissionDate: null,
      progress: 0,
      invitedDate: "2024-01-16",
      avatar: "https://randomuser.me/api/portraits/women/3.jpg"
    },
    {
      id: 4,
      name: "David Kim",
      email: "david.kim@email.com",
      assignedChallenge: "React Native Mobile App",
      status: "evaluated",
      submissionDate: "2024-01-12",
      progress: 100,
      invitedDate: "2024-01-05",
      avatar: "https://randomuser.me/api/portraits/men/4.jpg"
    },
    {
      id: 5,
      name: "Lisa Thompson",
      email: "lisa.thompson@email.com",
      assignedChallenge: "Python Data Analysis",
      status: "in-progress",
      submissionDate: null,
      progress: 45,
      invitedDate: "2024-01-13",
      avatar: "https://randomuser.me/api/portraits/women/5.jpg"
    }
  ];

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
    { id: 'candidates', label: 'Candidates', icon: 'Users' },
    { id: 'challenges', label: 'Challenges', icon: 'Code' },
    { id: 'reports', label: 'Reports', icon: 'BarChart3' }
  ];

  const handleTabChange = (tabId) => {
    setSelectedTab(tabId);
  };

  const handleInviteCandidate = () => {
    setIsInviteModalOpen(true);
  };

  const handleCloseInviteModal = () => {
    setIsInviteModalOpen(false);
  };

  const handleInviteSubmit = (inviteData) => {
    console.log('Invite candidate:', inviteData);
    setIsInviteModalOpen(false);
    // Here you would typically send the invitation
  };

  const filteredCandidates = candidatesData.filter(candidate => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         candidate.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         candidate.assignedChallenge.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || candidate.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const sortedCandidates = [...filteredCandidates].sort((a, b) => {
    if (!sortConfig.key) return 0;
    
    const aValue = a[sortConfig.key];
    const bValue = b[sortConfig.key];
    
    if (aValue < bValue) {
      return sortConfig.direction === 'asc' ? -1 : 1;
    }
    if (aValue > bValue) {
      return sortConfig.direction === 'asc' ? 1 : -1;
    }
    return 0;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <RoleBasedNavigation userRole="recruiter" currentPath="/recruiter-dashboard" />
      
      {/* Header with Notifications and Profile */}
      <div className="bg-surface border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-text-primary">Recruiter Dashboard</h1>
              <p className="text-text-secondary mt-1">Manage candidates and track assessment progress</p>
            </div>
            <div className="flex items-center space-x-4">
              <NotificationIndicator userRole="recruiter" />
              <UserProfileDropdown 
                userRole="recruiter" 
                userName="Jane Smith" 
                userEmail="jane.smith@company.com" 
              />
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <BreadcrumbNavigation currentPath="/recruiter-dashboard" userRole="recruiter" />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Tab Navigation */}
        <div className="mb-8">
          <div className="border-b border-border">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm transition-smooth min-h-touch flex items-center space-x-2 ${
                    selectedTab === tab.id
                      ? 'border-primary text-primary-600' :'border-transparent text-text-secondary hover:text-text-primary hover:border-secondary-300'
                  }`}
                >
                  <Icon name={tab.icon} size={18} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Dashboard Content */}
        {selectedTab === 'dashboard' && (
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
            {/* Main Content Area */}
            <div className="xl:col-span-3 space-y-8">
              {/* Summary Cards */}
              <SummaryCards metrics={dashboardMetrics} />

              {/* Candidates Table */}
              <div className="bg-surface rounded-lg border border-border">
                <div className="p-6 border-b border-border-light">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                    <h2 className="text-lg font-semibold text-text-primary">Recent Candidates</h2>
                    <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                      {/* Search */}
                      <div className="relative">
                        <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted" />
                        <input
                          type="text"
                          placeholder="Search candidates..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10 pr-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 text-sm min-w-[200px]"
                        />
                      </div>
                      
                      {/* Status Filter */}
                      <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 text-sm"
                      >
                        <option value="all">All Status</option>
                        <option value="invited">Invited</option>
                        <option value="in-progress">In Progress</option>
                        <option value="submitted">Submitted</option>
                        <option value="evaluated">Evaluated</option>
                      </select>
                    </div>
                  </div>
                </div>

                <CandidatesTable 
                  candidates={sortedCandidates}
                  selectedCandidates={selectedCandidates}
                  setSelectedCandidates={setSelectedCandidates}
                  sortConfig={sortConfig}
                  onSort={handleSort}
                />
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="xl:col-span-1 space-y-6">
              <QuickActionsPanel onInviteCandidate={handleInviteCandidate} />
              <RecentActivity />
            </div>
          </div>
        )}

        {/* Other Tab Contents */}
        {selectedTab === 'candidates' && (
          <div className="bg-surface rounded-lg border border-border p-8 text-center">
            <Icon name="Users" size={48} className="text-text-muted mx-auto mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-2">Candidates Management</h3>
            <p className="text-text-secondary">Detailed candidate management interface coming soon.</p>
          </div>
        )}

        {selectedTab === 'challenges' && (
          <div className="bg-surface rounded-lg border border-border p-8 text-center">
            <Icon name="Code" size={48} className="text-text-muted mx-auto mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-2">Challenge Overview</h3>
            <p className="text-text-secondary">Challenge management and assignment interface coming soon.</p>
          </div>
        )}

        {selectedTab === 'reports' && (
          <div className="bg-surface rounded-lg border border-border p-8 text-center">
            <Icon name="BarChart3" size={48} className="text-text-muted mx-auto mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-2">Analytics & Reports</h3>
            <p className="text-text-secondary">Comprehensive reporting dashboard coming soon.</p>
          </div>
        )}
      </div>

      {/* Invite Candidate Modal */}
      {isInviteModalOpen && (
        <InviteCandidateModal
          isOpen={isInviteModalOpen}
          onClose={handleCloseInviteModal}
          onSubmit={handleInviteSubmit}
        />
      )}
    </div>
  );
};

export default RecruiterDashboard;