import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import RoleBasedNavigation from 'components/ui/RoleBasedNavigation';
import BreadcrumbNavigation from 'components/ui/BreadcrumbNavigation';
import ChallengeDetails from './components/ChallengeDetails';
import SubmissionForm from './components/SubmissionForm';
import SubmissionHistory from './components/SubmissionHistory';
import NoChallenge from './components/NoChallenge';

const CandidatePortal = () => {
  const [activeTab, setActiveTab] = useState('details');
  const [assignedChallenge, setAssignedChallenge] = useState(null);
  const [submissions, setSubmissions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Mock candidate data
  const candidateData = {
    id: 1,
    name: "Alex Johnson",
    email: "alex.johnson@example.com",
    status: "active"
  };

  // Mock assigned challenge data
  const mockChallenge = {
    id: 1,
    title: "React E-commerce Dashboard",
    difficulty: "Intermediate",
    estimatedTime: "4-6 hours",
    assignedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    status: "in-progress",
    description: `Build a comprehensive e-commerce dashboard using React that displays product analytics, sales metrics, and inventory management features.

The dashboard should include:
• Interactive charts showing sales trends over time
• Product performance metrics with filtering capabilities
• Inventory status indicators with low-stock alerts
• Responsive design that works on desktop and mobile devices
• Clean, professional UI following modern design principles

Technical Requirements:
• Use React functional components with hooks
• Implement state management for data handling
• Create reusable components for charts and metrics
• Ensure proper error handling and loading states
• Write clean, well-documented code with proper naming conventions`,
    starterCode: `import React, { useState, useEffect } from 'react';
import './Dashboard.css';

const Dashboard = () => {
  const [salesData, setSalesData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch sales data
    fetchSalesData();
  }, []);

  const fetchSalesData = async () => {
    // TODO: Implement data fetching logic
    setLoading(false);
  };

  return (
    <div className="dashboard">
      <h1>E-commerce Dashboard</h1>
      {/* TODO: Implement dashboard components */}
    </div>
  );
};

export default Dashboard;`,
    submissionGuidelines: `Repository Structure:
Your repository should follow this structure:
/
├── README.md (with setup instructions)
├── package.json
├── src/
│   ├── components/
│   ├── pages/
│   ├── utils/
│   └── App.js
└── public/

Submission Requirements:
• Repository must be public on GitHub
• Include a comprehensive README with setup instructions
• All code should be properly commented
• Include screenshots of the working application
• Provide live demo link if deployed
• Ensure all dependencies are listed in package.json

Git Commit Guidelines:
• Use meaningful commit messages
• Make frequent, small commits showing your progress
• Include a final commit with "Final submission" message`,
    evaluationCriteria: `Your submission will be evaluated based on:

Code Quality (30%)
• Clean, readable, and well-organized code
• Proper use of React best practices
• Appropriate component structure and reusability
• Error handling and edge case management

Functionality (25%)
• All required features implemented correctly
• Interactive elements work as expected
• Data visualization accuracy
• Responsive design implementation

Technical Implementation (25%)
• Efficient state management
• Proper use of React hooks
• Performance optimization
• Code modularity and maintainability

User Experience (20%)
• Intuitive and user-friendly interface
• Consistent design patterns
• Accessibility considerations
• Mobile responsiveness

Bonus Points:
• Creative additional features
• Exceptional code documentation
• Advanced React patterns usage
• Performance optimizations`
  };

  // Mock submission history
  const mockSubmissions = [
    {
      id: 1,
      repositoryUrl: "https://github.com/alexjohnson/react-dashboard-v1",
      submittedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      status: "submitted",
      feedback: "Initial submission - good structure, needs refinement on charts"
    }
  ];

  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      setAssignedChallenge(mockChallenge);
      setSubmissions(mockSubmissions);
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleSubmission = (repositoryUrl) => {
    const newSubmission = {
      id: submissions.length + 1,
      repositoryUrl,
      submittedAt: new Date(),
      status: "submitted",
      feedback: null
    };
    
    setSubmissions([...submissions, newSubmission]);
    
    // Update challenge status
    setAssignedChallenge(prev => ({
      ...prev,
      status: "submitted"
    }));
  };

  const tabs = [
    { id: 'details', label: 'Challenge Details', icon: 'FileText' },
    { id: 'code', label: 'Starter Code', icon: 'Code' },
    { id: 'guidelines', label: 'Submission Guidelines', icon: 'CheckSquare' },
    { id: 'criteria', label: 'Evaluation Criteria', icon: 'Award' }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <RoleBasedNavigation userRole="candidate" currentPath="/candidate-portal" />
        <BreadcrumbNavigation currentPath="/candidate-portal" userRole="candidate" />
        
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-text-secondary">Loading your challenge...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedNavigation userRole="candidate" currentPath="/candidate-portal" />
      <BreadcrumbNavigation currentPath="/candidate-portal" userRole="candidate" />
      
      <div className="pt-4">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-text-primary">Candidate Portal</h1>
                <p className="text-text-secondary mt-2">Welcome back, {candidateData.name}</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm text-text-secondary">Status</p>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-success-100 text-success-700">
                    <Icon name="CheckCircle" size={16} className="mr-1" />
                    Active
                  </span>
                </div>
              </div>
            </div>
          </div>

          {!assignedChallenge ? (
            <NoChallenge />
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2">
                {/* Challenge Header */}
                <div className="bg-surface rounded-lg shadow-card border border-border p-6 mb-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-text-primary mb-2">
                        {assignedChallenge.title}
                      </h2>
                      <div className="flex items-center space-x-4">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                          assignedChallenge.difficulty === 'Easy' ? 'bg-success-100 text-success-700' :
                          assignedChallenge.difficulty === 'Intermediate'? 'bg-warning-100 text-warning-700' : 'bg-error-100 text-error-700'
                        }`}>
                          {assignedChallenge.difficulty}
                        </span>
                        <span className="flex items-center text-text-secondary">
                          <Icon name="Clock" size={16} className="mr-1" />
                          {assignedChallenge.estimatedTime}
                        </span>
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      assignedChallenge.status === 'assigned' ? 'bg-secondary-100 text-secondary-700' :
                      assignedChallenge.status === 'in-progress'? 'bg-warning-100 text-warning-700' : 'bg-success-100 text-success-700'
                    }`}>
                      {assignedChallenge.status.replace('-', ' ').toUpperCase()}
                    </div>
                  </div>

                  {/* Progress Info */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-secondary-50 rounded-lg">
                    <div>
                      <p className="text-sm text-text-secondary">Assigned</p>
                      <p className="font-medium text-text-primary">
                        {assignedChallenge.assignedDate.toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-text-secondary">Deadline</p>
                      <p className="font-medium text-text-primary">
                        {assignedChallenge.deadline.toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-text-secondary">Time Remaining</p>
                      <p className="font-medium text-warning">
                        {Math.ceil((assignedChallenge.deadline - new Date()) / (1000 * 60 * 60 * 24))} days
                      </p>
                    </div>
                  </div>
                </div>

                {/* Tabs */}
                <div className="bg-surface rounded-lg shadow-card border border-border">
                  {/* Tab Navigation */}
                  <div className="border-b border-border-light">
                    <nav className="flex space-x-8 px-6" aria-label="Tabs">
                      {tabs.map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setActiveTab(tab.id)}
                          className={`py-4 px-1 border-b-2 font-medium text-sm transition-smooth min-h-touch flex items-center space-x-2 ${
                            activeTab === tab.id
                              ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-secondary-300'
                          }`}
                        >
                          <Icon name={tab.icon} size={16} />
                          <span className="hidden sm:inline">{tab.label}</span>
                        </button>
                      ))}
                    </nav>
                  </div>

                  {/* Tab Content */}
                  <div className="p-6">
                    <ChallengeDetails 
                      challenge={assignedChallenge} 
                      activeTab={activeTab} 
                    />
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Submission Form */}
                <SubmissionForm 
                  onSubmit={handleSubmission}
                  isSubmitted={assignedChallenge.status === 'submitted'}
                />

                {/* Submission History */}
                <SubmissionHistory submissions={submissions} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CandidatePortal;