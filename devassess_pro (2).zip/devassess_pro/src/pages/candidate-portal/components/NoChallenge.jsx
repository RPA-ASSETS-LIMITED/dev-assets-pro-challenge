import React from 'react';
import Icon from 'components/AppIcon';

const NoChallenge = () => {
  return (
    <div className="bg-surface rounded-lg shadow-card border border-border p-8">
      <div className="text-center max-w-2xl mx-auto">
        <div className="w-24 h-24 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Icon name="Inbox" size={48} className="text-secondary-400" />
        </div>
        
        <h2 className="text-2xl font-bold text-text-primary mb-4">No Active Challenge</h2>
        <p className="text-text-secondary mb-6 leading-relaxed">
          You don't have any active coding challenges at the moment. Challenges are assigned by recruiters 
          based on job applications and interview processes.
        </p>

        <div className="bg-accent-50 rounded-lg p-6 border border-accent-200 mb-8">
          <div className="flex items-start space-x-4">
            <Icon name="Info" size={24} className="text-accent-600 flex-shrink-0 mt-1" />
            <div className="text-left">
              <h3 className="font-semibold text-accent-800 mb-2">What happens next?</h3>
              <ul className="text-sm text-accent-700 space-y-2">
                <li className="flex items-start space-x-2">
                  <Icon name="Check" size={16} className="flex-shrink-0 mt-0.5" />
                  <span>Recruiters will assign challenges based on your profile and job applications</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Icon name="Check" size={16} className="flex-shrink-0 mt-0.5" />
                  <span>You'll receive an email notification when a challenge is assigned</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Icon name="Check" size={16} className="flex-shrink-0 mt-0.5" />
                  <span>Each challenge comes with detailed requirements and evaluation criteria</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Icon name="Check" size={16} className="flex-shrink-0 mt-0.5" />
                  <span>You can only work on one challenge at a time to ensure quality focus</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-surface border border-border-light rounded-lg p-6">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                <Icon name="User" size={20} className="text-primary-600" />
              </div>
              <h4 className="font-semibold text-text-primary">Complete Your Profile</h4>
            </div>
            <p className="text-sm text-text-secondary mb-4">
              Make sure your profile is complete to increase your chances of receiving relevant challenges.
            </p>
            <button
              onClick={() => window.location.href = '/candidate-profile'}
              className="w-full bg-primary text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-primary-700 transition-smooth min-h-touch"
            >
              View Profile
            </button>
          </div>

          <div className="bg-surface border border-border-light rounded-lg p-6">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-success-100 rounded-lg flex items-center justify-center">
                <Icon name="Trophy" size={20} className="text-success-600" />
              </div>
              <h4 className="font-semibold text-text-primary">Check Leaderboard</h4>
            </div>
            <p className="text-sm text-text-secondary mb-4">
              See how other candidates are performing and get inspired by top performers.
            </p>
            <button
              onClick={() => window.location.href = '/global-leaderboard'}
              className="w-full bg-success text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-success-600 transition-smooth min-h-touch"
            >
              View Leaderboard
            </button>
          </div>
        </div>

        <div className="bg-warning-50 rounded-lg p-6 border border-warning-200">
          <div className="flex items-start space-x-4">
            <Icon name="Clock" size={24} className="text-warning-600 flex-shrink-0 mt-1" />
            <div className="text-left">
              <h3 className="font-semibold text-warning-800 mb-2">Stay Ready</h3>
              <p className="text-sm text-warning-700">
                Challenges can be assigned at any time. Make sure to check your email regularly and 
                keep your development environment ready for when opportunities arise.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoChallenge;