import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const SubmissionForm = ({ onSubmit, isSubmitted }) => {
  const [repositoryUrl, setRepositoryUrl] = useState('');
  const [isValidUrl, setIsValidUrl] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const validateGitUrl = (url) => {
    const gitUrlPattern = /^https:\/\/(github\.com|gitlab\.com|bitbucket\.org)\/[\w\-\.]+\/[\w\-\.]+\/?$/;
    return gitUrlPattern.test(url);
  };

  const handleUrlChange = (e) => {
    const url = e.target.value;
    setRepositoryUrl(url);
    setIsValidUrl(validateGitUrl(url));
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!isValidUrl) {
      setError('Please enter a valid Git repository URL');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      // Simulate submission delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      onSubmit(repositoryUrl);
      setRepositoryUrl('');
    } catch (err) {
      setError('Failed to submit. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="GitBranch" size={20} className="text-primary" />
        <h3 className="text-lg font-semibold text-text-primary">Submit Solution</h3>
      </div>

      {isSubmitted ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="CheckCircle" size={32} className="text-success-600" />
          </div>
          <h4 className="text-lg font-medium text-text-primary mb-2">Solution Submitted!</h4>
          <p className="text-text-secondary mb-4">
            Your solution has been submitted successfully. You'll receive feedback once it's evaluated.
          </p>
          <div className="p-4 bg-success-50 rounded-lg border border-success-200">
            <p className="text-sm text-success-700">
              You can still update your submission by providing a new repository URL if needed.
            </p>
          </div>
        </div>
      ) : (
        <div>
          <p className="text-text-secondary mb-4">
            Submit your solution by providing the Git repository URL containing your code.
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="repository-url" className="block text-sm font-medium text-text-primary mb-2">
                Repository URL *
              </label>
              <div className="relative">
                <input
                  type="url"
                  id="repository-url"
                  value={repositoryUrl}
                  onChange={handleUrlChange}
                  placeholder="https://github.com/username/repository-name"
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth ${
                    error ? 'border-error' : repositoryUrl && isValidUrl ?'border-success' : 'border-border'
                  }`}
                  disabled={isSubmitting}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  {repositoryUrl && (
                    <Icon 
                      name={isValidUrl ? "CheckCircle" : "XCircle"} 
                      size={20} 
                      className={isValidUrl ? "text-success" : "text-error"} 
                    />
                  )}
                </div>
              </div>
              {error && (
                <p className="mt-2 text-sm text-error flex items-center">
                  <Icon name="AlertCircle" size={16} className="mr-1" />
                  {error}
                </p>
              )}
              {repositoryUrl && isValidUrl && (
                <p className="mt-2 text-sm text-success flex items-center">
                  <Icon name="CheckCircle" size={16} className="mr-1" />
                  Valid repository URL
                </p>
              )}
            </div>

            <div className="bg-secondary-50 rounded-lg p-4">
              <h4 className="font-medium text-text-primary mb-2">Supported Platforms:</h4>
              <div className="flex items-center space-x-6 text-sm text-text-secondary">
                <div className="flex items-center space-x-2">
                  <Icon name="Github" size={16} />
                  <span>GitHub</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="GitBranch" size={16} />
                  <span>GitLab</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="GitBranch" size={16} />
                  <span>Bitbucket</span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={!isValidUrl || isSubmitting}
              className="w-full bg-primary text-white py-3 px-4 rounded-lg font-medium hover:bg-primary-700 focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth min-h-touch flex items-center justify-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <Icon name="Upload" size={20} />
                  <span>Submit Solution</span>
                </>
              )}
            </button>
          </form>
        </div>
      )}

      <div className="mt-6 p-4 bg-accent-50 rounded-lg border border-accent-200">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-accent-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-medium text-accent-800 mb-1">Submission Tips</h4>
            <ul className="text-sm text-accent-700 space-y-1">
              <li>• Ensure your repository is public and accessible</li>
              <li>• Include a comprehensive README with setup instructions</li>
              <li>• Make sure all dependencies are listed in package.json</li>
              <li>• Test your application before submitting</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubmissionForm;