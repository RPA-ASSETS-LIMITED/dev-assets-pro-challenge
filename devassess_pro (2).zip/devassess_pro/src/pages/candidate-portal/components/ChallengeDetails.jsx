import React from 'react';
import Icon from 'components/AppIcon';

const ChallengeDetails = ({ challenge, activeTab }) => {
  const renderContent = () => {
    switch (activeTab) {
      case 'details':
        return (
          <div className="prose max-w-none">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-text-primary mb-4">Challenge Description</h3>
              <div className="text-text-secondary leading-relaxed whitespace-pre-line">
                {challenge.description}
              </div>
            </div>
          </div>
        );

      case 'code':
        return (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text-primary">Starter Code</h3>
              <button
                onClick={() => navigator.clipboard.writeText(challenge.starterCode)}
                className="flex items-center space-x-2 px-3 py-2 text-sm bg-secondary-100 hover:bg-secondary-200 text-text-secondary hover:text-text-primary rounded-lg transition-smooth"
              >
                <Icon name="Copy" size={16} />
                <span>Copy Code</span>
              </button>
            </div>
            <div className="bg-secondary-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-sm text-secondary-100 font-mono">
                <code>{challenge.starterCode}</code>
              </pre>
            </div>
            <div className="mt-4 p-4 bg-accent-50 rounded-lg border border-accent-200">
              <div className="flex items-start space-x-3">
                <Icon name="Info" size={20} className="text-accent-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-accent-800 mb-1">Getting Started</h4>
                  <p className="text-sm text-accent-700">
                    Use this starter code as a foundation for your solution. You can modify and extend it as needed to meet the requirements.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'guidelines':
        return (
          <div>
            <h3 className="text-lg font-semibold text-text-primary mb-4">Submission Guidelines</h3>
            <div className="text-text-secondary leading-relaxed whitespace-pre-line">
              {challenge.submissionGuidelines}
            </div>
            <div className="mt-6 p-4 bg-warning-50 rounded-lg border border-warning-200">
              <div className="flex items-start space-x-3">
                <Icon name="AlertTriangle" size={20} className="text-warning-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-warning-800 mb-1">Important Note</h4>
                  <p className="text-sm text-warning-700">
                    Make sure your repository is public and accessible. Private repositories cannot be evaluated.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'criteria':
        return (
          <div>
            <h3 className="text-lg font-semibold text-text-primary mb-4">Evaluation Criteria</h3>
            <div className="text-text-secondary leading-relaxed whitespace-pre-line">
              {challenge.evaluationCriteria}
            </div>
            <div className="mt-6 p-4 bg-success-50 rounded-lg border border-success-200">
              <div className="flex items-start space-x-3">
                <Icon name="Target" size={20} className="text-success-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-success-800 mb-1">Success Tip</h4>
                  <p className="text-sm text-success-700">
                    Focus on code quality and user experience. A well-structured, clean solution often scores higher than a feature-heavy but messy implementation.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-[400px]">
      {renderContent()}
    </div>
  );
};

export default ChallengeDetails;