import React from 'react';
import Icon from 'components/AppIcon';

const SubmissionHistory = ({ submissions }) => {
  const getStatusIcon = (status) => {
    switch (status) {
      case 'submitted':
        return 'Clock';
      case 'evaluated':
        return 'CheckCircle';
      case 'rejected':
        return 'XCircle';
      default:
        return 'FileText';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'submitted':
        return 'text-warning bg-warning-100';
      case 'evaluated':
        return 'text-success bg-success-100';
      case 'rejected':
        return 'text-error bg-error-100';
      default:
        return 'text-secondary bg-secondary-100';
    }
  };

  const formatDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const truncateUrl = (url, maxLength = 40) => {
    if (url.length <= maxLength) return url;
    return url.substring(0, maxLength) + '...';
  };

  return (
    <div className="bg-surface rounded-lg shadow-card border border-border p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="History" size={20} className="text-primary" />
        <h3 className="text-lg font-semibold text-text-primary">Submission History</h3>
      </div>

      {submissions.length === 0 ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="FileText" size={32} className="text-secondary-400" />
          </div>
          <h4 className="text-lg font-medium text-text-primary mb-2">No Submissions Yet</h4>
          <p className="text-text-secondary">
            Your submission history will appear here once you submit your solution.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {submissions.map((submission) => (
            <div key={submission.id} className="border border-border-light rounded-lg p-4 hover:bg-secondary-50 transition-smooth">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(submission.status)}`}>
                      <Icon name={getStatusIcon(submission.status)} size={12} className="mr-1" />
                      {submission.status.charAt(0).toUpperCase() + submission.status.slice(1)}
                    </span>
                    <span className="text-sm text-text-secondary">
                      {formatDate(submission.submittedAt)}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="GitBranch" size={16} className="text-text-muted flex-shrink-0" />
                    <a
                      href={submission.repositoryUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary-700 text-sm font-medium truncate transition-smooth"
                      title={submission.repositoryUrl}
                    >
                      {truncateUrl(submission.repositoryUrl)}
                    </a>
                    <button
                      onClick={() => window.open(submission.repositoryUrl, '_blank')}
                      className="p-1 text-text-muted hover:text-text-primary transition-smooth"
                      title="Open in new tab"
                    >
                      <Icon name="ExternalLink" size={14} />
                    </button>
                  </div>

                  {submission.feedback && (
                    <div className="mt-3 p-3 bg-accent-50 rounded-lg border border-accent-200">
                      <div className="flex items-start space-x-2">
                        <Icon name="MessageSquare" size={16} className="text-accent-600 flex-shrink-0 mt-0.5" />
                        <div>
                          <h5 className="font-medium text-accent-800 text-sm mb-1">Feedback</h5>
                          <p className="text-sm text-accent-700">{submission.feedback}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {submissions.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border-light">
          <div className="flex items-center justify-between text-sm text-text-secondary">
            <span>Total Submissions: {submissions.length}</span>
            <span>Latest: {formatDate(submissions[submissions.length - 1]?.submittedAt)}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubmissionHistory;