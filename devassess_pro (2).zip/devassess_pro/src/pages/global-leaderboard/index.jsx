import React, { useState, useMemo } from 'react';
import Icon from 'components/AppIcon';
import RoleBasedNavigation from 'components/ui/RoleBasedNavigation';
import BreadcrumbNavigation from 'components/ui/BreadcrumbNavigation';
import LeaderboardTable from './components/LeaderboardTable';
import LeaderboardStats from './components/LeaderboardStats';
import FilterControls from './components/FilterControls';
import ExportModal from './components/ExportModal';
import CandidateDetailModal from './components/CandidateDetailModal';

const GlobalLeaderboard = () => {
  const [userRole] = useState('admin');
  const [filters, setFilters] = useState({
    difficulty: 'all',
    dateRange: 'all',
    category: 'all',
    status: 'all',
    search: ''
  });
  const [sortConfig, setSortConfig] = useState({
    key: 'rank',
    direction: 'asc'
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  // Mock leaderboard data
  const mockLeaderboardData = [
    {
      id: 1,
      rank: 1,
      name: "Sarah Chen",
      email: "sarah.chen@email.com",
      avatar: "https://randomuser.me/api/portraits/women/1.jpg",
      totalChallenges: 12,
      completedChallenges: 11,
      averageTime: "2h 45m",
      difficultyLevels: ["Easy", "Medium", "Hard"],
      overallScore: 94.5,
      badges: ["Speed Demon", "Problem Solver", "Code Master"],
      recentActivity: "Completed React Advanced Challenge",
      joinDate: "2024-01-15",
      lastActive: "2024-03-15",
      skills: ["React", "JavaScript", "Node.js", "Python"],
      githubProfile: "https://github.com/sarahchen"
    },
    {
      id: 2,
      rank: 2,
      name: "Michael Rodriguez",
      email: "michael.rodriguez@email.com",
      avatar: "https://randomuser.me/api/portraits/men/2.jpg",
      totalChallenges: 10,
      completedChallenges: 9,
      averageTime: "3h 12m",
      difficultyLevels: ["Easy", "Medium"],
      overallScore: 89.2,
      badges: ["Consistent Performer", "Team Player"],
      recentActivity: "Submitted Full Stack Challenge",
      joinDate: "2024-02-01",
      lastActive: "2024-03-14",
      skills: ["Vue.js", "JavaScript", "MongoDB", "Express"],
      githubProfile: "https://github.com/mrodriguez"
    },
    {
      id: 3,
      rank: 3,
      name: "Emily Johnson",
      email: "emily.johnson@email.com",
      avatar: "https://randomuser.me/api/portraits/women/3.jpg",
      totalChallenges: 8,
      completedChallenges: 8,
      averageTime: "2h 30m",
      difficultyLevels: ["Easy", "Medium", "Hard"],
      overallScore: 87.8,
      badges: ["Perfect Score", "Quick Learner"],
      recentActivity: "Completed Algorithm Challenge",
      joinDate: "2024-02-10",
      lastActive: "2024-03-13",
      skills: ["Angular", "TypeScript", "Java", "Spring"],
      githubProfile: "https://github.com/emilyjohnson"
    },
    {
      id: 4,
      rank: 4,
      name: "David Kim",
      email: "david.kim@email.com",
      avatar: "https://randomuser.me/api/portraits/men/4.jpg",
      totalChallenges: 15,
      completedChallenges: 12,
      averageTime: "4h 15m",
      difficultyLevels: ["Easy", "Medium"],
      overallScore: 85.3,
      badges: ["Persistent", "Detail Oriented"],
      recentActivity: "Working on Database Challenge",
      joinDate: "2024-01-20",
      lastActive: "2024-03-15",
      skills: ["Python", "Django", "PostgreSQL", "Docker"],
      githubProfile: "https://github.com/davidkim"
    },
    {
      id: 5,
      rank: 5,
      name: "Lisa Wang",
      email: "lisa.wang@email.com",
      avatar: "https://randomuser.me/api/portraits/women/5.jpg",
      totalChallenges: 6,
      completedChallenges: 6,
      averageTime: "3h 45m",
      difficultyLevels: ["Easy", "Medium"],
      overallScore: 82.7,
      badges: ["Rising Star", "Clean Code"],
      recentActivity: "Completed Frontend Challenge",
      joinDate: "2024-02-25",
      lastActive: "2024-03-12",
      skills: ["React", "CSS", "JavaScript", "Figma"],
      githubProfile: "https://github.com/lisawang"
    }
  ];

  // Filter and sort data
  const filteredAndSortedData = useMemo(() => {
    let filtered = mockLeaderboardData.filter(candidate => {
      const matchesSearch = candidate.name.toLowerCase().includes(filters.search.toLowerCase()) ||
                           candidate.email.toLowerCase().includes(filters.search.toLowerCase());
      
      const matchesDifficulty = filters.difficulty === 'all' || 
                               candidate.difficultyLevels.some(level => 
                                 level.toLowerCase() === filters.difficulty.toLowerCase()
                               );
      
      const matchesStatus = filters.status === 'all' || 
                           (filters.status === 'active' && candidate.completedChallenges < candidate.totalChallenges) ||
                           (filters.status === 'completed' && candidate.completedChallenges === candidate.totalChallenges);
      
      return matchesSearch && matchesDifficulty && matchesStatus;
    });

    // Sort data
    if (sortConfig.key) {
      filtered.sort((a, b) => {
        let aValue = a[sortConfig.key];
        let bValue = b[sortConfig.key];
        
        if (typeof aValue === 'string') {
          aValue = aValue.toLowerCase();
          bValue = bValue.toLowerCase();
        }
        
        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    return filtered;
  }, [filters, sortConfig]);

  // Pagination
  const totalPages = Math.ceil(filteredAndSortedData.length / itemsPerPage);
  const paginatedData = filteredAndSortedData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleSort = (key) => {
    setSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
    setCurrentPage(1);
  };

  const handleCandidateClick = (candidate) => {
    setSelectedCandidate(candidate);
  };

  const handleExport = () => {
    setIsExportModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedNavigation userRole={userRole} currentPath="/global-leaderboard" />
      <BreadcrumbNavigation currentPath="/global-leaderboard" userRole={userRole} />
      
      <div className="pt-4 pb-8">
        <div className="max-w-7xl mx-auto px-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-text-primary mb-2">Global Leaderboard</h1>
                <p className="text-text-secondary">
                  Track candidate performance and rankings across all challenges
                </p>
              </div>
              <div className="mt-4 lg:mt-0 flex items-center space-x-3">
                <button
                  onClick={handleExport}
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-secondary-100 text-secondary-700 rounded-lg hover:bg-secondary-200 transition-smooth min-h-touch"
                >
                  <Icon name="Download" size={16} />
                  <span>Export Data</span>
                </button>
                <div className="flex items-center space-x-2 text-sm text-text-secondary">
                  <Icon name="Users" size={16} />
                  <span>{filteredAndSortedData.length} candidates</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {/* Main Content */}
            <div className="xl:col-span-3 space-y-6">
              {/* Filter Controls */}
              <FilterControls
                filters={filters}
                onFilterChange={handleFilterChange}
              />

              {/* Leaderboard Table */}
              <LeaderboardTable
                data={paginatedData}
                sortConfig={sortConfig}
                onSort={handleSort}
                onCandidateClick={handleCandidateClick}
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>

            {/* Sidebar Stats */}
            <div className="xl:col-span-1">
              <LeaderboardStats data={mockLeaderboardData} />
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {isExportModalOpen && (
        <ExportModal
          data={filteredAndSortedData}
          onClose={() => setIsExportModalOpen(false)}
        />
      )}

      {selectedCandidate && (
        <CandidateDetailModal
          candidate={selectedCandidate}
          onClose={() => setSelectedCandidate(null)}
        />
      )}
    </div>
  );
};

export default GlobalLeaderboard;