import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const CandidateDetailModal = ({ candidate, onClose }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'User' },
    { id: 'challenges', label: 'Challenges', icon: 'Code' },
    { id: 'performance', label: 'Performance', icon: 'TrendingUp' },
    { id: 'activity', label: 'Activity', icon: 'Activity' }
  ];

  const mockChallengeHistory = [
    {
      id: 1,
      title: "React Advanced Components",
      difficulty: "Hard",
      score: 95,
      completionTime: "2h 30m",
      submittedAt: "2024-03-15",
      status: "completed",
      feedback: "Excellent implementation with clean code structure"
    },
    {
      id: 2,
      title: "Algorithm Optimization",
      difficulty: "Medium",
      score: 88,
      completionTime: "1h 45m",
      submittedAt: "2024-03-12",
      status: "completed",
      feedback: "Good solution, could be optimized further"
    },
    {
      id: 3,
      title: "Database Design Challenge",
      difficulty: "Hard",
      score: 92,
      completionTime: "3h 15m",
      submittedAt: "2024-03-10",
      status: "completed",
      feedback: "Well-structured database schema"
    }
  ];

  const mockActivityLog = [
    {
      id: 1,
      action: "Completed React Advanced Components",
      timestamp: "2024-03-15 14:30",
      type: "completion"
    },
    {
      id: 2,
      action: "Started Database Design Challenge",
      timestamp: "2024-03-10 09:15",
      type: "start"
    },
    {
      id: 3,
      action: "Submitted Algorithm Optimization",
      timestamp: "2024-03-12 16:45",
      type: "submission"
    },
    {
      id: 4,
      action: "Joined the platform",
      timestamp: "2024-01-15 10:00",
      type: "registration"
    }
  ];

  const getDifficultyColor = (difficulty) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'bg-success-100 text-success-700';
      case 'medium':
        return 'bg-warning-100 text-warning-700';
      case 'hard':
        return 'bg-error-100 text-error-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 80) return 'text-warning';
    if (score >= 70) return 'text-accent';
    return 'text-error';
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case 'completion':
        return 'CheckCircle';
      case 'start':
        return 'Play';
      case 'submission':
        return 'Upload';
      case 'registration':
        return 'UserPlus';
      default:
        return 'Activity';
    }
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Basic Info */}
      <div className="flex items-start space-x-4">
        <div className="w-20 h-20 rounded-full overflow-hidden bg-secondary-200 flex-shrink-0">
          <Image
            src={candidate.avatar}
            alt={candidate.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-text-primary mb-1">{candidate.name}</h3>
          <p className="text-text-secondary mb-2">{candidate.email}</p>
          <div className="flex flex-wrap gap-2">
            {candidate.badges.map((badge, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-medium"
              >
                {badge}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-secondary-50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Trophy" size={16} className="text-warning" />
            <span className="text-sm font-medium text-text-secondary">Rank</span>
          </div>
          <div className="text-2xl font-bold text-text-primary">#{candidate.rank}</div>
        </div>
        
        <div className="bg-secondary-50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Target" size={16} className="text-success" />
            <span className="text-sm font-medium text-text-secondary">Score</span>
          </div>
          <div className={`text-2xl font-bold ${getScoreColor(candidate.overallScore)}`}>
            {candidate.overallScore}
          </div>
        </div>
        
        <div className="bg-secondary-50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Code" size={16} className="text-accent" />
            <span className="text-sm font-medium text-text-secondary">Challenges</span>
          </div>
          <div className="text-2xl font-bold text-text-primary">
            {candidate.completedChallenges}/{candidate.totalChallenges}
          </div>
        </div>
        
        <div className="bg-secondary-50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Clock" size={16} className="text-primary" />
            <span className="text-sm font-medium text-text-secondary">Avg Time</span>
          </div>
          <div className="text-2xl font-bold text-text-primary">{candidate.averageTime}</div>
        </div>
      </div>

      {/* Skills */}
      <div>
        <h4 className="text-lg font-semibold text-text-primary mb-3">Skills</h4>
        <div className="flex flex-wrap gap-2">
          {candidate.skills.map((skill, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-accent-100 text-accent-700 rounded-lg text-sm"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>

      {/* Additional Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
        <div>
          <span className="text-text-secondary">Joined:</span>
          <span className="ml-2 text-text-primary font-medium">{candidate.joinDate}</span>
        </div>
        <div>
          <span className="text-text-secondary">Last Active:</span>
          <span className="ml-2 text-text-primary font-medium">{candidate.lastActive}</span>
        </div>
      </div>
    </div>
  );

  const renderChallengesTab = () => (
    <div className="space-y-4">
      {mockChallengeHistory.map((challenge) => (
        <div key={challenge.id} className="border border-border-light rounded-lg p-4">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h4 className="font-semibold text-text-primary">{challenge.title}</h4>
              <div className="flex items-center space-x-3 mt-1">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(challenge.difficulty)}`}>
                  {challenge.difficulty}
                </span>
                <span className="text-sm text-text-secondary">
                  Completed in {challenge.completionTime}
                </span>
              </div>
            </div>
            <div className="text-right">
              <div className={`text-xl font-bold ${getScoreColor(challenge.score)}`}>
                {challenge.score}
              </div>
              <div className="text-xs text-text-muted">score</div>
            </div>
          </div>
          
          <div className="text-sm text-text-secondary mb-2">
            Submitted on {challenge.submittedAt}
          </div>
          
          {challenge.feedback && (
            <div className="bg-secondary-50 rounded-lg p-3">
              <div className="flex items-start space-x-2">
                <Icon name="MessageSquare" size={16} className="text-accent mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-text-primary mb-1">Feedback</div>
                  <div className="text-sm text-text-secondary">{challenge.feedback}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );

  const renderPerformanceTab = () => (
    <div className="space-y-6">
      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="text-center p-4 bg-success-50 rounded-lg">
          <div className="text-2xl font-bold text-success mb-1">
            {Math.round((candidate.completedChallenges / candidate.totalChallenges) * 100)}%
          </div>
          <div className="text-sm text-text-secondary">Completion Rate</div>
        </div>
        
        <div className="text-center p-4 bg-warning-50 rounded-lg">
          <div className="text-2xl font-bold text-warning mb-1">
            {candidate.averageTime}
          </div>
          <div className="text-sm text-text-secondary">Average Time</div>
        </div>
        
        <div className="text-center p-4 bg-primary-50 rounded-lg">
          <div className="text-2xl font-bold text-primary mb-1">
            {candidate.difficultyLevels.length}
          </div>
          <div className="text-sm text-text-secondary">Difficulty Levels</div>
        </div>
      </div>

      {/* Difficulty Breakdown */}
      <div>
        <h4 className="text-lg font-semibold text-text-primary mb-3">Difficulty Mastery</h4>
        <div className="space-y-3">
          {candidate.difficultyLevels.map((level, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getDifficultyColor(level)}`}>
                {level}
              </span>
              <div className="flex-1 mx-4">
                <div className="w-full bg-secondary-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      level === 'Easy' ? 'bg-success' :
                      level === 'Medium' ? 'bg-warning' : 'bg-error'
                    }`}
                    style={{ width: `${Math.random() * 40 + 60}%` }}
                  ></div>
                </div>
              </div>
              <span className="text-sm text-text-secondary">
                {Math.floor(Math.random() * 5) + 3} challenges
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderActivityTab = () => (
    <div className="space-y-4">
      {mockActivityLog.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-3">
          <div className="flex-shrink-0 w-8 h-8 bg-secondary-100 rounded-full flex items-center justify-center">
            <Icon name={getActivityIcon(activity.type)} size={16} className="text-secondary-600" />
          </div>
          <div className="flex-1">
            <div className="text-sm font-medium text-text-primary">{activity.action}</div>
            <div className="text-xs text-text-muted">{activity.timestamp}</div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return renderOverviewTab();
      case 'challenges':
        return renderChallengesTab();
      case 'performance':
        return renderPerformanceTab();
      case 'activity':
        return renderActivityTab();
      default:
        return renderOverviewTab();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1020 p-4">
      <div className="bg-surface rounded-lg shadow-modal max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border-light">
          <h2 className="text-xl font-semibold text-text-primary">Candidate Details</h2>
          <div className="flex items-center space-x-3">
            <a
              href={candidate.githubProfile}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 px-3 py-1 bg-secondary-100 text-secondary-700 rounded-lg hover:bg-secondary-200 transition-smooth text-sm min-h-touch"
            >
              <Icon name="Github" size={16} />
              <span>GitHub</span>
            </a>
            <button
              onClick={onClose}
              className="p-2 hover:bg-secondary-50 rounded-lg transition-smooth min-h-touch min-w-touch"
            >
              <Icon name="X" size={20} className="text-text-muted" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-border-light">
          <div className="flex space-x-8 px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 py-4 border-b-2 transition-smooth ${
                  activeTab === tab.id
                    ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary'
                }`}
              >
                <Icon name={tab.icon} size={16} />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default CandidateDetailModal;