import React from 'react';
import Icon from 'components/AppIcon';

const FilterControls = ({ filters, onFilterChange }) => {
  const handleFilterUpdate = (key, value) => {
    onFilterChange({
      ...filters,
      [key]: value
    });
  };

  const clearAllFilters = () => {
    onFilterChange({
      difficulty: 'all',
      dateRange: 'all',
      category: 'all',
      status: 'all',
      search: ''
    });
  };

  const hasActiveFilters = Object.values(filters).some(value => value !== 'all' && value !== '');

  return (
    <div className="bg-surface rounded-lg border border-border shadow-card p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Search */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Icon 
              name="Search" 
              size={20} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted" 
            />
            <input
              type="text"
              placeholder="Search candidates..."
              value={filters.search}
              onChange={(e) => handleFilterUpdate('search', e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth min-h-touch"
            />
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Difficulty Filter */}
          <div className="relative">
            <select
              value={filters.difficulty}
              onChange={(e) => handleFilterUpdate('difficulty', e.target.value)}
              className="appearance-none bg-surface border border-border rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth min-h-touch"
            >
              <option value="all">All Difficulties</option>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
            <Icon 
              name="ChevronDown" 
              size={16} 
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-text-muted pointer-events-none" 
            />
          </div>

          {/* Date Range Filter */}
          <div className="relative">
            <select
              value={filters.dateRange}
              onChange={(e) => handleFilterUpdate('dateRange', e.target.value)}
              className="appearance-none bg-surface border border-border rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth min-h-touch"
            >
              <option value="all">All Time</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="quarter">This Quarter</option>
            </select>
            <Icon 
              name="ChevronDown" 
              size={16} 
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-text-muted pointer-events-none" 
            />
          </div>

          {/* Category Filter */}
          <div className="relative">
            <select
              value={filters.category}
              onChange={(e) => handleFilterUpdate('category', e.target.value)}
              className="appearance-none bg-surface border border-border rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth min-h-touch"
            >
              <option value="all">All Categories</option>
              <option value="frontend">Frontend</option>
              <option value="backend">Backend</option>
              <option value="fullstack">Full Stack</option>
              <option value="algorithms">Algorithms</option>
              <option value="database">Database</option>
            </select>
            <Icon 
              name="ChevronDown" 
              size={16} 
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-text-muted pointer-events-none" 
            />
          </div>

          {/* Status Filter */}
          <div className="relative">
            <select
              value={filters.status}
              onChange={(e) => handleFilterUpdate('status', e.target.value)}
              className="appearance-none bg-surface border border-border rounded-lg px-4 py-2 pr-8 text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-smooth min-h-touch"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
            </select>
            <Icon 
              name="ChevronDown" 
              size={16} 
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-text-muted pointer-events-none" 
            />
          </div>

          {/* Clear Filters */}
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="inline-flex items-center space-x-2 px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-secondary-50 rounded-lg transition-smooth min-h-touch"
            >
              <Icon name="X" size={16} />
              <span>Clear</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="mt-4 pt-4 border-t border-border-light">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm text-text-secondary">Active filters:</span>
            
            {filters.search && (
              <span className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm">
                <span>Search: "{filters.search}"</span>
                <button
                  onClick={() => handleFilterUpdate('search', '')}
                  className="hover:text-primary-800 transition-smooth"
                >
                  <Icon name="X" size={14} />
                </button>
              </span>
            )}
            
            {filters.difficulty !== 'all' && (
              <span className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm">
                <span>Difficulty: {filters.difficulty}</span>
                <button
                  onClick={() => handleFilterUpdate('difficulty', 'all')}
                  className="hover:text-primary-800 transition-smooth"
                >
                  <Icon name="X" size={14} />
                </button>
              </span>
            )}
            
            {filters.dateRange !== 'all' && (
              <span className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm">
                <span>Date: {filters.dateRange}</span>
                <button
                  onClick={() => handleFilterUpdate('dateRange', 'all')}
                  className="hover:text-primary-800 transition-smooth"
                >
                  <Icon name="X" size={14} />
                </button>
              </span>
            )}
            
            {filters.category !== 'all' && (
              <span className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm">
                <span>Category: {filters.category}</span>
                <button
                  onClick={() => handleFilterUpdate('category', 'all')}
                  className="hover:text-primary-800 transition-smooth"
                >
                  <Icon name="X" size={14} />
                </button>
              </span>
            )}
            
            {filters.status !== 'all' && (
              <span className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm">
                <span>Status: {filters.status}</span>
                <button
                  onClick={() => handleFilterUpdate('status', 'all')}
                  className="hover:text-primary-800 transition-smooth"
                >
                  <Icon name="X" size={14} />
                </button>
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterControls;