import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const ExportModal = ({ data, onClose }) => {
  const [exportFormat, setExportFormat] = useState('csv');
  const [exportFields, setExportFields] = useState({
    rank: true,
    name: true,
    email: true,
    totalChallenges: true,
    completedChallenges: true,
    averageTime: true,
    overallScore: true,
    difficultyLevels: true,
    badges: false,
    joinDate: false,
    lastActive: false
  });
  const [isExporting, setIsExporting] = useState(false);

  const handleFieldToggle = (field) => {
    setExportFields(prev => ({
      ...prev,
      [field]: !prev[field]
    }));
  };

  const handleSelectAll = () => {
    const allSelected = Object.values(exportFields).every(value => value);
    const newState = {};
    Object.keys(exportFields).forEach(key => {
      newState[key] = !allSelected;
    });
    setExportFields(newState);
  };

  const generateCSV = () => {
    const selectedFields = Object.keys(exportFields).filter(field => exportFields[field]);
    const headers = selectedFields.map(field => {
      switch (field) {
        case 'rank': return 'Rank';
        case 'name': return 'Name';
        case 'email': return 'Email';
        case 'totalChallenges': return 'Total Challenges';
        case 'completedChallenges': return 'Completed Challenges';
        case 'averageTime': return 'Average Time';
        case 'overallScore': return 'Overall Score';
        case 'difficultyLevels': return 'Difficulty Levels';
        case 'badges': return 'Badges';
        case 'joinDate': return 'Join Date';
        case 'lastActive': return 'Last Active';
        default: return field;
      }
    });

    const rows = data.map(candidate => {
      return selectedFields.map(field => {
        const value = candidate[field];
        if (Array.isArray(value)) {
          return `"${value.join(', ')}"`;
        }
        return `"${value}"`;
      });
    });

    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const generateJSON = () => {
    const selectedFields = Object.keys(exportFields).filter(field => exportFields[field]);
    return JSON.stringify(
      data.map(candidate => {
        const filtered = {};
        selectedFields.forEach(field => {
          filtered[field] = candidate[field];
        });
        return filtered;
      }),
      null,
      2
    );
  };

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      let content, filename, mimeType;
      
      if (exportFormat === 'csv') {
        content = generateCSV();
        filename = `leaderboard-${new Date().toISOString().split('T')[0]}.csv`;
        mimeType = 'text/csv';
      } else {
        content = generateJSON();
        filename = `leaderboard-${new Date().toISOString().split('T')[0]}.json`;
        mimeType = 'application/json';
      }

      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setTimeout(() => {
        setIsExporting(false);
        onClose();
      }, 1000);
    } catch (error) {
      console.error('Export failed:', error);
      setIsExporting(false);
    }
  };

  const selectedFieldsCount = Object.values(exportFields).filter(Boolean).length;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1020 p-4">
      <div className="bg-surface rounded-lg shadow-modal max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border-light">
          <h2 className="text-xl font-semibold text-text-primary">Export Leaderboard Data</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-secondary-50 rounded-lg transition-smooth min-h-touch min-w-touch"
          >
            <Icon name="X" size={20} className="text-text-muted" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Export Format */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-text-primary mb-3">
              Export Format
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setExportFormat('csv')}
                className={`p-3 rounded-lg border-2 transition-smooth text-left ${
                  exportFormat === 'csv' ?'border-primary bg-primary-50 text-primary-700' :'border-border hover:border-secondary-300'
                }`}
              >
                <div className="flex items-center space-x-2 mb-1">
                  <Icon name="FileText" size={16} />
                  <span className="font-medium">CSV</span>
                </div>
                <div className="text-xs text-text-secondary">
                  Comma-separated values
                </div>
              </button>
              
              <button
                onClick={() => setExportFormat('json')}
                className={`p-3 rounded-lg border-2 transition-smooth text-left ${
                  exportFormat === 'json' ?'border-primary bg-primary-50 text-primary-700' :'border-border hover:border-secondary-300'
                }`}
              >
                <div className="flex items-center space-x-2 mb-1">
                  <Icon name="Code" size={16} />
                  <span className="font-medium">JSON</span>
                </div>
                <div className="text-xs text-text-secondary">
                  JavaScript Object Notation
                </div>
              </button>
            </div>
          </div>

          {/* Field Selection */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-medium text-text-primary">
                Select Fields ({selectedFieldsCount} selected)
              </label>
              <button
                onClick={handleSelectAll}
                className="text-sm text-accent hover:text-accent-600 transition-smooth"
              >
                {Object.values(exportFields).every(value => value) ? 'Deselect All' : 'Select All'}
              </button>
            </div>
            
            <div className="space-y-2 max-h-48 overflow-y-auto border border-border-light rounded-lg p-3">
              {Object.entries(exportFields).map(([field, checked]) => (
                <label key={field} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => handleFieldToggle(field)}
                    className="w-4 h-4 text-primary border-border rounded focus:ring-primary-500"
                  />
                  <span className="text-sm text-text-primary capitalize">
                    {field.replace(/([A-Z])/g, ' $1').trim()}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Export Info */}
          <div className="bg-secondary-50 rounded-lg p-4 mb-6">
            <div className="flex items-start space-x-2">
              <Icon name="Info" size={16} className="text-accent mt-0.5" />
              <div className="text-sm">
                <div className="text-text-primary font-medium mb-1">Export Summary</div>
                <div className="text-text-secondary space-y-1">
                  <div>• {data.length} candidates will be exported</div>
                  <div>• {selectedFieldsCount} fields selected</div>
                  <div>• Format: {exportFormat.toUpperCase()}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t border-border-light">
          <button
            onClick={onClose}
            className="px-4 py-2 text-text-secondary hover:text-text-primary hover:bg-secondary-50 rounded-lg transition-smooth min-h-touch"
          >
            Cancel
          </button>
          <button
            onClick={handleExport}
            disabled={selectedFieldsCount === 0 || isExporting}
            className="inline-flex items-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth min-h-touch"
          >
            {isExporting ? (
              <>
                <Icon name="Loader2" size={16} className="animate-spin" />
                <span>Exporting...</span>
              </>
            ) : (
              <>
                <Icon name="Download" size={16} />
                <span>Export Data</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExportModal;