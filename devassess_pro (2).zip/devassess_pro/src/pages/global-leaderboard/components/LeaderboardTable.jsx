import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const LeaderboardTable = ({ 
  data, 
  sortConfig, 
  onSort, 
  onCandidateClick, 
  currentPage, 
  totalPages, 
  onPageChange 
}) => {
  const getSortIcon = (columnKey) => {
    if (sortConfig.key !== columnKey) {
      return <Icon name="ArrowUpDown" size={14} className="text-text-muted" />;
    }
    return sortConfig.direction === 'asc' 
      ? <Icon name="ArrowUp" size={14} className="text-primary" />
      : <Icon name="ArrowDown" size={14} className="text-primary" />;
  };

  const getDifficultyBadgeColor = (level) => {
    switch (level.toLowerCase()) {
      case 'easy':
        return 'bg-success-100 text-success-700';
      case 'medium':
        return 'bg-warning-100 text-warning-700';
      case 'hard':
        return 'bg-error-100 text-error-700';
      default:
        return 'bg-secondary-100 text-secondary-700';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 80) return 'text-warning';
    if (score >= 70) return 'text-accent';
    return 'text-error';
  };

  const renderPagination = () => {
    const pages = [];
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return (
      <div className="flex items-center justify-between px-6 py-4 border-t border-border-light">
        <div className="flex items-center space-x-2 text-sm text-text-secondary">
          <span>
            Showing {((currentPage - 1) * 10) + 1} to {Math.min(currentPage * 10, data.length)} of {data.length} results
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="p-2 rounded-lg border border-border hover:bg-secondary-50 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth min-h-touch min-w-touch"
          >
            <Icon name="ChevronLeft" size={16} />
          </button>
          
          {pages.map(page => (
            <button
              key={page}
              onClick={() => onPageChange(page)}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-smooth min-h-touch ${
                currentPage === page
                  ? 'bg-primary text-white' :'text-text-secondary hover:bg-secondary-50 hover:text-text-primary'
              }`}
            >
              {page}
            </button>
          ))}
          
          <button
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="p-2 rounded-lg border border-border hover:bg-secondary-50 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth min-h-touch min-w-touch"
          >
            <Icon name="ChevronRight" size={16} />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-surface rounded-lg border border-border shadow-card overflow-hidden">
      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-secondary-50 border-b border-border-light">
            <tr>
              <th className="px-6 py-4 text-left">
                <button
                  onClick={() => onSort('rank')}
                  className="flex items-center space-x-2 text-sm font-semibold text-text-primary hover:text-primary transition-smooth"
                >
                  <span>Rank</span>
                  {getSortIcon('rank')}
                </button>
              </th>
              <th className="px-6 py-4 text-left">
                <button
                  onClick={() => onSort('name')}
                  className="flex items-center space-x-2 text-sm font-semibold text-text-primary hover:text-primary transition-smooth"
                >
                  <span>Candidate</span>
                  {getSortIcon('name')}
                </button>
              </th>
              <th className="px-6 py-4 text-left">
                <button
                  onClick={() => onSort('completedChallenges')}
                  className="flex items-center space-x-2 text-sm font-semibold text-text-primary hover:text-primary transition-smooth"
                >
                  <span>Challenges</span>
                  {getSortIcon('completedChallenges')}
                </button>
              </th>
              <th className="px-6 py-4 text-left">
                <button
                  onClick={() => onSort('averageTime')}
                  className="flex items-center space-x-2 text-sm font-semibold text-text-primary hover:text-primary transition-smooth"
                >
                  <span>Avg Time</span>
                  {getSortIcon('averageTime')}
                </button>
              </th>
              <th className="px-6 py-4 text-left">
                <span className="text-sm font-semibold text-text-primary">Difficulty</span>
              </th>
              <th className="px-6 py-4 text-left">
                <button
                  onClick={() => onSort('overallScore')}
                  className="flex items-center space-x-2 text-sm font-semibold text-text-primary hover:text-primary transition-smooth"
                >
                  <span>Score</span>
                  {getSortIcon('overallScore')}
                </button>
              </th>
              <th className="px-6 py-4 text-left">
                <span className="text-sm font-semibold text-text-primary">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border-light">
            {data.map((candidate) => (
              <tr key={candidate.id} className="hover:bg-secondary-50 transition-smooth">
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      candidate.rank === 1 ? 'bg-warning-100 text-warning-700' :
                      candidate.rank === 2 ? 'bg-secondary-200 text-secondary-700' :
                      candidate.rank === 3 ? 'bg-warning-50 text-warning-600': 'bg-secondary-100 text-secondary-600'
                    }`}>
                      {candidate.rank}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => onCandidateClick(candidate)}
                    className="flex items-center space-x-3 hover:text-primary transition-smooth text-left"
                  >
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-secondary-200">
                      <Image
                        src={candidate.avatar}
                        alt={candidate.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="font-medium text-text-primary">{candidate.name}</div>
                      <div className="text-sm text-text-secondary">{candidate.email}</div>
                    </div>
                  </button>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm">
                    <div className="font-medium text-text-primary">
                      {candidate.completedChallenges}/{candidate.totalChallenges}
                    </div>
                    <div className="text-text-secondary">completed</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm font-medium text-text-primary">{candidate.averageTime}</span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-1">
                    {candidate.difficultyLevels.map((level, index) => (
                      <span
                        key={index}
                        className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyBadgeColor(level)}`}
                      >
                        {level}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <span className={`text-lg font-bold ${getScoreColor(candidate.overallScore)}`}>
                      {candidate.overallScore}
                    </span>
                    <div className="w-16 bg-secondary-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          candidate.overallScore >= 90 ? 'bg-success' :
                          candidate.overallScore >= 80 ? 'bg-warning' :
                          candidate.overallScore >= 70 ? 'bg-accent' : 'bg-error'
                        }`}
                        style={{ width: `${candidate.overallScore}%` }}
                      ></div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => onCandidateClick(candidate)}
                    className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-lg hover:bg-primary-200 transition-smooth text-sm min-h-touch"
                  >
                    <Icon name="Eye" size={14} />
                    <span>View</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="lg:hidden divide-y divide-border-light">
        {data.map((candidate) => (
          <div key={candidate.id} className="p-4">
            <div className="flex items-start space-x-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                candidate.rank === 1 ? 'bg-warning-100 text-warning-700' :
                candidate.rank === 2 ? 'bg-secondary-200 text-secondary-700' :
                candidate.rank === 3 ? 'bg-warning-50 text-warning-600': 'bg-secondary-100 text-secondary-600'
              }`}>
                {candidate.rank}
              </div>
              
              <div className="flex-1 min-w-0">
                <button
                  onClick={() => onCandidateClick(candidate)}
                  className="flex items-center space-x-3 mb-3 hover:text-primary transition-smooth text-left w-full"
                >
                  <div className="w-10 h-10 rounded-full overflow-hidden bg-secondary-200 flex-shrink-0">
                    <Image
                      src={candidate.avatar}
                      alt={candidate.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-text-primary truncate">{candidate.name}</div>
                    <div className="text-sm text-text-secondary truncate">{candidate.email}</div>
                  </div>
                </button>
                
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-text-secondary">Challenges</div>
                    <div className="font-medium text-text-primary">
                      {candidate.completedChallenges}/{candidate.totalChallenges}
                    </div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Avg Time</div>
                    <div className="font-medium text-text-primary">{candidate.averageTime}</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Score</div>
                    <div className={`font-bold ${getScoreColor(candidate.overallScore)}`}>
                      {candidate.overallScore}
                    </div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Difficulty</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {candidate.difficultyLevels.slice(0, 2).map((level, index) => (
                        <span
                          key={index}
                          className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyBadgeColor(level)}`}
                        >
                          {level}
                        </span>
                      ))}
                      {candidate.difficultyLevels.length > 2 && (
                        <span className="text-xs text-text-muted">+{candidate.difficultyLevels.length - 2}</span>
                      )}
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => onCandidateClick(candidate)}
                  className="mt-3 w-full inline-flex items-center justify-center space-x-2 px-3 py-2 bg-primary-100 text-primary-700 rounded-lg hover:bg-primary-200 transition-smooth text-sm min-h-touch"
                >
                  <Icon name="Eye" size={16} />
                  <span>View Details</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && renderPagination()}
    </div>
  );
};

export default LeaderboardTable;