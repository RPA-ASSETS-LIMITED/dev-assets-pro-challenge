import React from 'react';
import Icon from 'components/AppIcon';

const LeaderboardStats = ({ data }) => {
  // Calculate statistics
  const totalCandidates = data.length;
  const activeCandidates = data.filter(c => c.completedChallenges < c.totalChallenges).length;
  const averageScore = (data.reduce((sum, c) => sum + c.overallScore, 0) / totalCandidates).toFixed(1);
  const topPerformers = data.slice(0, 3);
  
  const recentAchievements = [
    {
      id: 1,
      candidate: "Sarah Chen",
      achievement: "Completed React Advanced Challenge",
      time: "2 hours ago",
      type: "completion"
    },
    {
      id: 2,
      candidate: "Michael Rodriguez",
      achievement: "Achieved 90+ score streak",
      time: "4 hours ago",
      type: "milestone"
    },
    {
      id: 3,
      candidate: "Emily Johnson",
      achievement: "Perfect Algorithm Challenge score",
      time: "6 hours ago",
      type: "perfect"
    },
    {
      id: 4,
      candidate: "David Kim",
      achievement: "Completed 10th challenge",
      time: "1 day ago",
      type: "milestone"
    }
  ];

  const challengeStats = {
    totalChallenges: data.reduce((sum, c) => sum + c.totalChallenges, 0),
    completedChallenges: data.reduce((sum, c) => sum + c.completedChallenges, 0),
    averageCompletionTime: "3h 15m"
  };

  const getAchievementIcon = (type) => {
    switch (type) {
      case 'completion':
        return 'CheckCircle';
      case 'milestone':
        return 'Target';
      case 'perfect':
        return 'Star';
      default:
        return 'Award';
    }
  };

  const getAchievementColor = (type) => {
    switch (type) {
      case 'completion':
        return 'text-success';
      case 'milestone':
        return 'text-accent';
      case 'perfect':
        return 'text-warning';
      default:
        return 'text-primary';
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Overview</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Users" size={16} className="text-text-muted" />
              <span className="text-sm text-text-secondary">Total Candidates</span>
            </div>
            <span className="text-lg font-bold text-text-primary">{totalCandidates}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Activity" size={16} className="text-text-muted" />
              <span className="text-sm text-text-secondary">Active</span>
            </div>
            <span className="text-lg font-bold text-success">{activeCandidates}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="TrendingUp" size={16} className="text-text-muted" />
              <span className="text-sm text-text-secondary">Avg Score</span>
            </div>
            <span className="text-lg font-bold text-accent">{averageScore}</span>
          </div>
          
          <div className="pt-2 border-t border-border-light">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-text-secondary">Completion Rate</span>
              <span className="text-sm font-medium text-text-primary">
                {Math.round((challengeStats.completedChallenges / challengeStats.totalChallenges) * 100)}%
              </span>
            </div>
            <div className="w-full bg-secondary-200 rounded-full h-2">
              <div
                className="bg-success h-2 rounded-full transition-all duration-300"
                style={{ 
                  width: `${Math.round((challengeStats.completedChallenges / challengeStats.totalChallenges) * 100)}%` 
                }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Performers */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Top Performers</h3>
        <div className="space-y-3">
          {topPerformers.map((candidate, index) => (
            <div key={candidate.id} className="flex items-center space-x-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                index === 0 ? 'bg-warning-100 text-warning-700' :
                index === 1 ? 'bg-secondary-200 text-secondary-700': 'bg-warning-50 text-warning-600'
              }`}>
                {index + 1}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-text-primary truncate">
                  {candidate.name}
                </div>
                <div className="text-xs text-text-secondary">
                  {candidate.completedChallenges} challenges completed
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-success">
                  {candidate.overallScore}
                </div>
                <div className="text-xs text-text-muted">score</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Achievements */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Recent Achievements</h3>
          <button className="text-sm text-accent hover:text-accent-600 transition-smooth">
            View All
          </button>
        </div>
        <div className="space-y-3">
          {recentAchievements.map((achievement) => (
            <div key={achievement.id} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 ${getAchievementColor(achievement.type)}`}>
                <Icon name={getAchievementIcon(achievement.type)} size={16} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-text-primary">
                  {achievement.candidate}
                </div>
                <div className="text-sm text-text-secondary">
                  {achievement.achievement}
                </div>
                <div className="text-xs text-text-muted mt-1">
                  {achievement.time}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Challenge Trends */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-4">Challenge Trends</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Total Challenges</span>
            <span className="text-sm font-medium text-text-primary">
              {challengeStats.totalChallenges}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Completed</span>
            <span className="text-sm font-medium text-success">
              {challengeStats.completedChallenges}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Avg Completion Time</span>
            <span className="text-sm font-medium text-text-primary">
              {challengeStats.averageCompletionTime}
            </span>
          </div>
          
          <div className="pt-2 border-t border-border-light">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">
                {Math.round((challengeStats.completedChallenges / challengeStats.totalChallenges) * 100)}%
              </div>
              <div className="text-sm text-text-secondary">Overall Progress</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeaderboardStats;