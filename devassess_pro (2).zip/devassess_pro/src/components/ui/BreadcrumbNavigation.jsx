import React from 'react';
import Icon from '../AppIcon';

const BreadcrumbNavigation = ({ currentPath = '/', userRole = 'admin' }) => {
  const pathSegments = currentPath.split('/').filter(segment => segment);
  
  const pathLabels = {
    'admin-dashboard': 'Admin Dashboard',
    'challenge-management': 'Challenge Management',
    'recruiter-dashboard': 'Recruiter Dashboard',
    'candidate-portal': 'Candidate Portal',
    'global-leaderboard': 'Global Leaderboard',
    'candidate-profile': 'Candidate Profile'
  };

  const generateBreadcrumbs = () => {
    const breadcrumbs = [
      { label: 'Home', path: '/', isActive: false }
    ];

    let currentPathBuild = '';
    pathSegments.forEach((segment, index) => {
      currentPathBuild += `/${segment}`;
      const isLast = index === pathSegments.length - 1;
      
      breadcrumbs.push({
        label: pathLabels[segment] || segment.charAt(0).toUpperCase() + segment.slice(1).replace('-', ' '),
        path: currentPathBuild,
        isActive: isLast
      });
    });

    return breadcrumbs;
  };

  const breadcrumbs = generateBreadcrumbs();

  const handleNavigation = (path) => {
    if (path !== currentPath) {
      window.location.href = path;
    }
  };

  if (currentPath === '/' || pathSegments.length === 0) {
    return null;
  }

  return (
    <nav className="bg-surface border-b border-border-light" aria-label="Breadcrumb">
      <div className="max-w-7xl mx-auto px-6 py-3">
        <ol className="flex items-center space-x-2 text-sm">
          {breadcrumbs.map((breadcrumb, index) => (
            <li key={breadcrumb.path} className="flex items-center">
              {index > 0 && (
                <Icon 
                  name="ChevronRight" 
                  size={16} 
                  className="text-text-muted mx-2" 
                />
              )}
              
              {breadcrumb.isActive ? (
                <span className="text-text-primary font-medium" aria-current="page">
                  {breadcrumb.label}
                </span>
              ) : (
                <button
                  onClick={() => handleNavigation(breadcrumb.path)}
                  className="text-text-secondary hover:text-primary-600 transition-smooth focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-1 rounded px-1 py-0.5"
                >
                  {breadcrumb.label}
                </button>
              )}
            </li>
          ))}
        </ol>
      </div>
    </nav>
  );
};

export default BreadcrumbNavigation;