import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const RoleBasedNavigation = ({ userRole = 'admin', currentPath = '/' }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);

  const navigationItems = {
    admin: [
      { label: 'Admin Dashboard', path: '/admin-dashboard', icon: 'LayoutDashboard' },
      { label: 'Challenge Management', path: '/challenge-management', icon: 'Settings' },
      { label: 'Global Leaderboard', path: '/global-leaderboard', icon: 'Trophy' },
      { label: 'Candidate Profile', path: '/candidate-profile', icon: 'Users' },
    ],
    recruiter: [
      { label: 'Recruiter Dashboard', path: '/recruiter-dashboard', icon: 'LayoutDashboard' },
      { label: 'Candidate Profile', path: '/candidate-profile', icon: 'Users' },
      { label: 'Global Leaderboard', path: '/global-leaderboard', icon: 'Trophy' },
    ],
    candidate: [
      { label: 'Candidate Portal', path: '/candidate-portal', icon: 'Code' },
      { label: 'Global Leaderboard', path: '/global-leaderboard', icon: 'Trophy' },
    ]
  };

  const currentItems = navigationItems[userRole] || navigationItems.admin;

  const handleNavigation = (path) => {
    window.location.href = path;
    setIsMobileMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleDropdownToggle = (dropdown) => {
    setActiveDropdown(activeDropdown === dropdown ? null : dropdown);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.dropdown-container')) {
        setActiveDropdown(null);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return (
    <nav className="fixed top-0 left-0 right-0 bg-surface border-b border-border z-1000">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="Code2" size={20} color="white" />
                </div>
                <span className="text-xl font-semibold text-text-primary">TechRecruit</span>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {currentItems.map((item) => (
                <button
                  key={item.path}
                  onClick={() => handleNavigation(item.path)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-smooth min-h-touch flex items-center space-x-2 ${
                    currentPath === item.path
                      ? 'bg-primary-100 text-primary-700' :'text-text-secondary hover:text-text-primary hover:bg-secondary-50'
                  }`}
                >
                  <Icon name={item.icon} size={16} />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* User Profile Dropdown */}
          <div className="hidden md:block">
            <div className="ml-4 flex items-center md:ml-6">
              <div className="relative dropdown-container">
                <button
                  onClick={() => handleDropdownToggle('profile')}
                  className="max-w-xs bg-surface rounded-full flex items-center text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-smooth min-h-touch min-w-touch"
                >
                  <div className="flex items-center space-x-2 px-3 py-2">
                    <div className="w-8 h-8 bg-secondary-200 rounded-full flex items-center justify-center">
                      <Icon name="User" size={16} color="#64748B" />
                    </div>
                    <span className="text-sm font-medium text-text-primary capitalize">{userRole}</span>
                    <Icon name="ChevronDown" size={16} className="text-text-secondary" />
                  </div>
                </button>

                {activeDropdown === 'profile' && (
                  <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-modal bg-surface ring-1 ring-border ring-opacity-5 z-1010">
                    <div className="py-1">
                      <button
                        onClick={() => console.log('Profile clicked')}
                        className="block w-full text-left px-4 py-2 text-sm text-text-secondary hover:bg-secondary-50 hover:text-text-primary transition-smooth"
                      >
                        <div className="flex items-center space-x-2">
                          <Icon name="User" size={16} />
                          <span>Profile Settings</span>
                        </div>
                      </button>
                      <button
                        onClick={() => console.log('Logout clicked')}
                        className="block w-full text-left px-4 py-2 text-sm text-text-secondary hover:bg-secondary-50 hover:text-text-primary transition-smooth"
                      >
                        <div className="flex items-center space-x-2">
                          <Icon name="LogOut" size={16} />
                          <span>Sign out</span>
                        </div>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMobileMenu}
              className="bg-surface inline-flex items-center justify-center p-2 rounded-md text-text-secondary hover:text-text-primary hover:bg-secondary-50 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500 transition-smooth min-h-touch min-w-touch"
            >
              <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-surface border-t border-border">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {currentItems.map((item) => (
              <button
                key={item.path}
                onClick={() => handleNavigation(item.path)}
                className={`w-full text-left px-3 py-2 rounded-md text-base font-medium transition-smooth min-h-touch flex items-center space-x-3 ${
                  currentPath === item.path
                    ? 'bg-primary-100 text-primary-700' :'text-text-secondary hover:text-text-primary hover:bg-secondary-50'
                }`}
              >
                <Icon name={item.icon} size={20} />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
          
          {/* Mobile User Profile */}
          <div className="pt-4 pb-3 border-t border-border">
            <div className="flex items-center px-5">
              <div className="w-10 h-10 bg-secondary-200 rounded-full flex items-center justify-center">
                <Icon name="User" size={20} color="#64748B" />
              </div>
              <div className="ml-3">
                <div className="text-base font-medium text-text-primary capitalize">{userRole}</div>
                <div className="text-sm font-medium text-text-secondary">user@example.com</div>
              </div>
            </div>
            <div className="mt-3 px-2 space-y-1">
              <button
                onClick={() => console.log('Profile clicked')}
                className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-text-secondary hover:text-text-primary hover:bg-secondary-50 transition-smooth min-h-touch flex items-center space-x-3"
              >
                <Icon name="User" size={20} />
                <span>Profile Settings</span>
              </button>
              <button
                onClick={() => console.log('Logout clicked')}
                className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-text-secondary hover:text-text-primary hover:bg-secondary-50 transition-smooth min-h-touch flex items-center space-x-3"
              >
                <Icon name="LogOut" size={20} />
                <span>Sign out</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default RoleBasedNavigation;