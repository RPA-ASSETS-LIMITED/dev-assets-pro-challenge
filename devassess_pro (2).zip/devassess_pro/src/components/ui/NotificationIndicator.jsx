import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const NotificationIndicator = ({ userRole = 'admin' }) => {
  const [notifications, setNotifications] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  // Mock notifications based on user role
  const mockNotifications = {
    admin: [
      {
        id: 1,
        title: 'New Challenge Submitted',
        message: 'React Developer Assessment has been submitted for review',
        type: 'info',
        timestamp: new Date(Date.now() - 5 * 60 * 1000),
        read: false
      },
      {
        id: 2,
        title: 'System Update',
        message: 'Platform maintenance scheduled for tonight at 2 AM',
        type: 'warning',
        timestamp: new Date(Date.now() - 30 * 60 * 1000),
        read: false
      },
      {
        id: 3,
        title: 'User Registration',
        message: '5 new candidates registered today',
        type: 'success',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
        read: true
      }
    ],
    recruiter: [
      {
        id: 1,
        title: 'Candidate Completed Assessment',
        message: 'John Doe finished the Frontend Developer challenge',
        type: 'success',
        timestamp: new Date(Date.now() - 10 * 60 * 1000),
        read: false
      },
      {
        id: 2,
        title: 'New Candidate Application',
        message: 'Sarah Wilson applied for Senior React position',
        type: 'info',
        timestamp: new Date(Date.now() - 45 * 60 * 1000),
        read: false
      }
    ],
    candidate: [
      {
        id: 1,
        title: 'New Challenge Available',
        message: 'Full Stack Developer Assessment is now available',
        type: 'info',
        timestamp: new Date(Date.now() - 15 * 60 * 1000),
        read: false
      },
      {
        id: 2,
        title: 'Assessment Reminder',
        message: 'React Challenge deadline is in 2 days',
        type: 'warning',
        timestamp: new Date(Date.now() - 60 * 60 * 1000),
        read: true
      }
    ]
  };

  useEffect(() => {
    const roleNotifications = mockNotifications[userRole] || [];
    setNotifications(roleNotifications);
    setUnreadCount(roleNotifications.filter(n => !n.read).length);
  }, [userRole]);

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'success':
        return 'CheckCircle';
      case 'warning':
        return 'AlertTriangle';
      case 'error':
        return 'AlertCircle';
      default:
        return 'Info';
    }
  };

  const getNotificationColor = (type) => {
    switch (type) {
      case 'success':
        return 'text-success';
      case 'warning':
        return 'text-warning';
      case 'error':
        return 'text-error';
      default:
        return 'text-accent';
    }
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const handleNotificationClick = (notificationId) => {
    setNotifications(prev => 
      prev.map(n => 
        n.id === notificationId ? { ...n, read: true } : n
      )
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    setUnreadCount(0);
  };

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.notification-container')) {
        setIsOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return (
    <div className="relative notification-container">
      <button
        onClick={toggleDropdown}
        className="relative p-2 text-text-secondary hover:text-text-primary focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 rounded-full transition-smooth min-h-touch min-w-touch"
      >
        <Icon name="Bell" size={20} />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-error rounded-full min-w-[20px] h-5">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-surface rounded-lg shadow-modal border border-border z-1015 max-h-96 overflow-hidden">
          <div className="p-4 border-b border-border-light">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-text-primary">Notifications</h3>
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="text-sm text-accent hover:text-accent-600 transition-smooth"
                >
                  Mark all read
                </button>
              )}
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-6 text-center">
                <Icon name="Bell" size={48} className="text-text-muted mx-auto mb-3" />
                <p className="text-text-secondary">No notifications yet</p>
              </div>
            ) : (
              <div className="divide-y divide-border-light">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 hover:bg-secondary-50 transition-smooth cursor-pointer ${
                      !notification.read ? 'bg-primary-50' : ''
                    }`}
                    onClick={() => handleNotificationClick(notification.id)}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`flex-shrink-0 ${getNotificationColor(notification.type)}`}>
                        <Icon name={getNotificationIcon(notification.type)} size={20} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`text-sm font-medium ${
                            !notification.read ? 'text-text-primary' : 'text-text-secondary'
                          }`}>
                            {notification.title}
                          </p>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></div>
                          )}
                        </div>
                        <p className="text-sm text-text-secondary mt-1 line-clamp-2">
                          {notification.message}
                        </p>
                        <p className="text-xs text-text-muted mt-2">
                          {formatTimestamp(notification.timestamp)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {notifications.length > 0 && (
            <div className="p-3 border-t border-border-light">
              <button
                onClick={() => console.log('View all notifications')}
                className="w-full text-center text-sm text-accent hover:text-accent-600 transition-smooth py-2"
              >
                View all notifications
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationIndicator;