import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const UserProfileDropdown = ({ userRole = 'admin', userName = 'John Doe', userEmail = 'john.doe@example.com' }) => {
  const [isOpen, setIsOpen] = useState(false);

  const roleConfig = {
    admin: {
      displayName: 'Administrator',
      color: 'bg-primary',
      textColor: 'text-primary-700'
    },
    recruiter: {
      displayName: 'Recruiter',
      color: 'bg-accent',
      textColor: 'text-accent-700'
    },
    candidate: {
      displayName: 'Candidate',
      color: 'bg-success',
      textColor: 'text-success-700'
    }
  };

  const currentRoleConfig = roleConfig[userRole] || roleConfig.admin;

  const menuItems = [
    {
      label: 'Profile Settings',
      icon: 'User',
      action: () => console.log('Profile settings clicked'),
      divider: false
    },
    {
      label: 'Account Settings',
      icon: 'Settings',
      action: () => console.log('Account settings clicked'),
      divider: false
    },
    {
      label: 'Help & Support',
      icon: 'HelpCircle',
      action: () => console.log('Help clicked'),
      divider: true
    },
    {
      label: 'Sign Out',
      icon: 'LogOut',
      action: () => console.log('Sign out clicked'),
      divider: false,
      danger: true
    }
  ];

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleMenuItemClick = (action) => {
    action();
    setIsOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.profile-dropdown-container')) {
        setIsOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const getInitials = (name) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="relative profile-dropdown-container">
      <button
        onClick={toggleDropdown}
        className="flex items-center space-x-3 p-2 rounded-lg hover:bg-secondary-50 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-smooth min-h-touch"
      >
        <div className={`w-8 h-8 ${currentRoleConfig.color} rounded-full flex items-center justify-center text-white text-sm font-medium`}>
          {getInitials(userName)}
        </div>
        <div className="hidden md:block text-left">
          <div className="text-sm font-medium text-text-primary">{userName}</div>
          <div className={`text-xs ${currentRoleConfig.textColor}`}>
            {currentRoleConfig.displayName}
          </div>
        </div>
        <Icon 
          name="ChevronDown" 
          size={16} 
          className={`text-text-secondary transition-transform duration-150 ${
            isOpen ? 'transform rotate-180' : ''
          }`} 
        />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-surface rounded-lg shadow-modal border border-border z-1010">
          {/* User Info Header */}
          <div className="p-4 border-b border-border-light">
            <div className="flex items-center space-x-3">
              <div className={`w-12 h-12 ${currentRoleConfig.color} rounded-full flex items-center justify-center text-white text-lg font-medium`}>
                {getInitials(userName)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-text-primary truncate">
                  {userName}
                </div>
                <div className="text-sm text-text-secondary truncate">
                  {userEmail}
                </div>
                <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mt-1 ${
                  currentRoleConfig.color === 'bg-primary' ? 'bg-primary-100 text-primary-700' :
                  currentRoleConfig.color === 'bg-accent'? 'bg-accent-100 text-accent-700' : 'bg-success-100 text-success-700'
                }`}>
                  {currentRoleConfig.displayName}
                </div>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="py-2">
            {menuItems.map((item, index) => (
              <React.Fragment key={index}>
                {item.divider && <div className="border-t border-border-light my-2"></div>}
                <button
                  onClick={() => handleMenuItemClick(item.action)}
                  className={`w-full text-left px-4 py-3 text-sm transition-smooth flex items-center space-x-3 ${
                    item.danger 
                      ? 'text-error hover:bg-error-50 hover:text-error-600' :'text-text-secondary hover:bg-secondary-50 hover:text-text-primary'
                  }`}
                >
                  <Icon 
                    name={item.icon} 
                    size={16} 
                    className={item.danger ? 'text-error' : 'text-text-muted'} 
                  />
                  <span>{item.label}</span>
                </button>
              </React.Fragment>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default UserProfileDropdown;