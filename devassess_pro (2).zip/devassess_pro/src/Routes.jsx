import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";

// Page imports
import AdminDashboard from "pages/admin-dashboard";
import ChallengeManagement from "pages/challenge-management";
import RecruiterDashboard from "pages/recruiter-dashboard";
import CandidatePortal from "pages/candidate-portal";
import GlobalLeaderboard from "pages/global-leaderboard";
import CandidateProfile from "pages/candidate-profile";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <ScrollToTop />
        <RouterRoutes>
          <Route path="/" element={<AdminDashboard />} />
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/challenge-management" element={<ChallengeManagement />} />
          <Route path="/recruiter-dashboard" element={<RecruiterDashboard />} />
          <Route path="/candidate-portal" element={<CandidatePortal />} />
          <Route path="/global-leaderboard" element={<GlobalLeaderboard />} />
          <Route path="/candidate-profile" element={<CandidateProfile />} />
        </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;